"""Streamlit interface for the medication review (Person 5).

Run from the project root:

    streamlit run app.py

Two tabs:

* Review current medicines - checks every medicine the patient already takes.
* Ask about a new medicine - the prescriber types a question ("¿Puedo añadirle
  ibuprofeno?"); the screen finds the medicine in it, answers the question from
  that medicine's technical sheet and checks the medicine against the patient's
  current medicines.

Both use the real system when it is available (see src/revision.py):

* Rules (Person 2): nomenclator codes from data/processed/prescriptions.json,
  or the ATC codes in data/catalogo_medicamentos.json when that file is missing.
* Interactions and typed questions (Person 3's RAG): the Groq model is called
  live when it is set up (full requirements, search index, GROQ_API_KEY). The
  screen then shows each step: the passages found in the sheet, the ones kept,
  what the model answered and the checks on its answer. Only when the model is
  not available here are the answers read from data/interacciones_guardadas.json
  (made by `python -m src.guardar_interacciones`), and the page says so at the top.

The report always says which checks did not run. When neither part is
available, the review tab shows SAMPLE findings under a "Sample data" banner.
"""
from __future__ import annotations

import json
import re

import streamlit as st
from pydantic import ValidationError

from src.config import PATIENTS_DIR, PROJECT_ROOT
from src.informe import generate_report, normalise_text, save_report
from src.modelos import Medication, Patient
from src.revision import (
    NOT_SPECIFIED,
    REASON_TEXT,
    answer_typed_question,
    asks_about_medicines,
    cloud_only_files,
    check_new_medicine,
    find_medicines,
    index_sheets,
    live_review_with_steps,
    load_catalogue,
    question_with_context,
    load_rule_data,
    load_stored_answers,
    model_status,
    planned_questions,
    review_patient,
    rules_status,
    stored_review,
)

DEMO_DIR = PROJECT_ROOT / "data" / "demo"
DEMO_PATIENTS_FILE = DEMO_DIR / "pacientes_demo.json"
SAMPLE_FINDINGS_FILE = DEMO_DIR / "hallazgos_ejemplo.json"

TYPE_LABELS = {
    "duplicado": "Duplicates",
    "advertencia_atc": "Same drug family",
    "interaccion": "Interactions (pairs)",
    "cascada": "Possible cascades",
}


def load_patients() -> tuple[list[tuple[Patient, str]], list[str]]:
    """Read Lucía's patient files and the demo patients, validated with Patient."""
    files = [(path, "patients") for path in sorted(PATIENTS_DIR.glob("*.json"))]
    if DEMO_PATIENTS_FILE.exists():
        files.append((DEMO_PATIENTS_FILE, "demo"))

    patients, problems = [], []
    for path, source in files:
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            problems.append(f"{path.name}: could not be read ({exc})")
            continue
        for item in data if isinstance(data, list) else [data]:
            try:
                patients.append((Patient.model_validate(item), source))
            except ValidationError as exc:
                problems.append(f"{path.name}: {exc.error_count()} validation error(s)")
    return patients, problems


def load_sample_findings() -> dict:
    return json.loads(SAMPLE_FINDINGS_FILE.read_text(encoding="utf-8"))


# Everything below is read once per server start and then reused, so changing
# patient or tab does not reload files or re-import the model's libraries.
@st.cache_data(show_spinner="Loading patients…")
def cached_patients():
    # cache_data hands back fresh copies, so patients always match the current
    # code (with cache_resource, a code reload left objects of the old class).
    return load_patients()


@st.cache_resource(show_spinner=False)
def cached_catalogue():
    return load_catalogue()


@st.cache_resource(show_spinner="Checking what is available…")
def cached_status():
    return model_status(), rules_status()


@st.cache_resource(show_spinner=False)
def cached_stored_answers():
    return load_stored_answers()


@st.cache_resource(show_spinner=False)
def cached_index_sheets():
    return index_sheets()


@st.cache_resource(show_spinner="Loading the medicine codes…")
def cached_rule_data():
    return load_rule_data(catalogue=cached_catalogue())


def saved_files(report) -> dict:
    paths = save_report(report)
    return {kind: (path.name, path.read_bytes()) for kind, path in paths.items()}


def show_counts(report, labels: list[tuple[str, str]]) -> None:
    cols = st.columns(len(labels))
    for col, (key, label) in zip(cols, labels):
        col.metric(label, "Not checked" if key in report.unchecked else report.counts[key])


def show_report(report, files: dict, key: str) -> None:
    """Downloads plus the report itself, for either tab."""
    if report.safety_flags:
        st.warning(
            f"{len(report.safety_flags)} generated text(s) were withheld because they "
            "contained treatment-change wording."
        )
    pdf_name, pdf_bytes = files["pdf"]
    html_name, html_bytes = files["html"]
    st.markdown("**Download the report**")
    d1, d2, d3 = st.columns([1, 1, 2])
    d1.download_button("PDF", data=pdf_bytes, file_name=pdf_name,
                       mime="application/pdf", key=f"{key}_pdf")
    d2.download_button("Web page", data=html_bytes, file_name=html_name,
                       mime="text/html", key=f"{key}_html")
    d3.caption(
        "PDF opens in Preview or any PDF reader. The web page opens in your browser "
        "and can be printed. Both are also saved in `output/`."
    )
    st.divider()
    st.markdown(report.markdown)


def what_runs(rules_ready: bool, interactions: str) -> str:
    parts = ["duplicates, drug families and cascades" if rules_ready
             else "duplicates by ingredient name only"]
    parts.append({
        "live": "interactions, asked to the AI model (Groq) now",
        "stored": "interactions, from answers the model saved earlier",
        "off": "no interactions",
    }[interactions])
    return "This check covers " + "; ".join(parts) + "."


def report_for(patient, checked, proposed=None, question=None, question_answer=None, scope_note=None):
    """The report for a review (or, with ``proposed``, for a new-medicine check)."""
    return generate_report(
        patient,
        checked.findings,
        checked_without_evidence=checked.checked_without_evidence,
        could_not_check=checked.could_not_check,
        proposed=proposed,
        unchecked_types=checked.unchecked,
        interaction_note=interaction_note,
        interaction_groups=checked.interaction_groups,
        same_ingredient=checked.same_ingredient,
        question=question,
        question_answer=question_answer,
        scope_note=scope_note,
    )


# --------------------------------------------------------------------------
# Showing each step of the AI (the RAG pipeline) as it happens
# --------------------------------------------------------------------------

OUTCOMES = {  # outcome -> (icon, short label, explanation)
    "found": ("🔶", "interaction described",
              "**Result: the sheet describes an interaction.** It goes into the report with its quotation."),
    "no_interaction": ("⚪", "no interaction described",
                       "**Result: the sheet mentions this medicine but describes no relevant interaction.**"),
    "not_found": ("⚪", "nothing found",
                  "**Result: nothing found in this sheet.** That does not mean the combination is safe."),
    "failed": ("⚠️", "could not be checked",
               "**Result: could not be checked.** It is listed under \"Checks that could not be completed\"."),
}
QUESTION_OUTCOMES = {
    "found": ("💬", "answered", "**Result: answer accepted.** It is shown at the top of the report."),
    "not_found": ("💬", "not enough information",
                  "**Result: the sheet does not have enough information to answer.**"),
    "failed": ("⚠️", "could not be answered", "**Result: the question could not be answered.**"),
}


def _md(text) -> str:
    """Plain text for st.markdown (no accidental bold, links or headings)."""
    return re.sub(r"([\\`*_\[\]#<>|$])", r"\\\1", str(text or "")).replace("\n", " ")


def _mention(text: str, word: str, limit: int = 320) -> str:
    """The sentence(s) of a passage that mention ``word``."""
    target = normalise_text(word)
    sentences = [x for x in re.split(r"(?<=[.;:])\s+", text or "") if target in normalise_text(x)]
    snippet = " ".join(sentences[:2]) or (text or "")
    return snippet if len(snippet) <= limit else snippet[:limit].rsplit(" ", 1)[0] + "…"


def render_step(stage: str, data: dict) -> None:
    """One step of a search, in plain words for the audience."""
    ingredient = data.get("ingredient")
    if stage == "retrieved":
        found = data["retrieved"]
        kept = data["kept_ids"]
        sheet = found[0]["nombre"] if found else "the"
        where = (f"section 4.5 (interactions) of the **{_md(sheet)}** technical sheet" if ingredient
                 else f"the **{_md(sheet)}** technical sheet")
        st.markdown(f"**① Search** {where}, by meaning, for: *{_md(data['question'])}*  \n"
                    f"The {len(found)} closest passage(s):" if found else
                    f"**① Search** the technical sheet: no passages in this section.")
        for f in found:
            similarity = 1 - float(f.get("distance", 0))
            mark = ""
            if ingredient:
                mark = (f" · ✔ mentions *{_md(ingredient)}*" if f.get("id") in kept
                        else f" · ✘ does not mention *{_md(ingredient)}*")
            st.markdown(f"- `{_md(f['seccion'])}` {_md(f['titulo'])} · similarity {similarity:.2f}{mark}")
        if ingredient:
            st.markdown(f"**② Keep** only passages that mention *{_md(ingredient)}*: "
                        f"**{len(kept)} of {len(found)}**")
            for f in found:
                if f.get("id") in kept:
                    st.caption(f"“…{_md(_mention(f['texto'], ingredient))}”")
            if not kept:
                st.markdown("No passage mentions it, so **the AI model is not asked** "
                            "(it never answers without a source).")
    elif stage == "retrying":
        st.markdown(f"⏳ The AI model did not answer (Groq's free plan limits requests per minute). "
                    f"Trying again in {data['seconds']} s…")
    elif stage == "asking":
        st.markdown(f"**③ Ask the AI model** (Groq, `{_md(data['model'])}`) with the question and only "
                    f"these {data['passages']} passage(s). Its rules: use only these texts, quote them "
                    "word for word, never tell anyone to start, stop or change a treatment…")
    elif stage == "answered":
        answer = data.get("answer") or {}
        status, reason = answer.get("status"), answer.get("reason")
        raw = answer.get("model_answer")
        shown = raw or (answer.get("response") if "model_answer" not in answer else None)
        if shown and status != "not_found" or (shown and reason == "insufficient_evidence"):
            took = f" ({answer['model_seconds']:.1f} s)" if (answer.get("model_seconds") or 0) >= 0.05 else ""
            label = "The model's answer" if "model_answer" in answer else "Answer"
            st.markdown(f"**{label}**{took}: {_md(shown.get('description'))}")
            for c in shown.get("citations") or []:
                st.markdown(f"> {_md(c.get('literal_quote'))}  \n> — section {_md(c.get('seccion'))}")
        if raw is not None or status in ("found", "rejected") or reason == "insufficient_evidence":
            checks = {
                "forbidden_phrase": ["❌ **Safety check:** the answer contained wording that tells someone to "
                                     "change a treatment, so it was **rejected**."],
                "invalid_citation": ["✔ Safety check: no instruction to start, stop or change a treatment.",
                                     "❌ **Quotation check:** a quotation is not word for word in the sheet, "
                                     "so the answer was **rejected** (nothing invented reaches the report)."],
                "invalid_response": ["❌ **Format check:** the answer was not in the required format, "
                                     "even after one retry, so it was **rejected**."],
            }.get(reason)
            if checks is None and status == "found":
                sections = ", ".join(dict.fromkeys(c.get("seccion", "") for c in (shown or {}).get("citations") or []))
                checks = ["✔ Safety check: no instruction to start, stop or change a treatment.",
                          f"✔ Quotation check: every quotation is word for word in the sheet (section {sections})."]
            elif checks is None and reason == "insufficient_evidence":
                checks = ["✔ Safety check passed. The model said these passages are not enough to answer."]
            if checks:
                st.markdown("**④ Check the answer**  \n" + "  \n".join(checks))
        elif reason == "generation_failed":
            st.markdown("❌ The AI model could not be reached (Groq).")
        elif reason == "not_stored":
            st.markdown("This search is not in the saved answers.")
        table = QUESTION_OUTCOMES if data.get("question_mode") else OUTCOMES
        outcome = data.get("outcome", "failed")
        icon, short, text = table.get(outcome, table["failed"])
        if outcome == "no_interaction" and data.get("question_mode"):
            icon, short, text = QUESTION_OUTCOMES["found"]
        detail = f" ({_md(data['detail'])})" if outcome == "failed" and data.get("detail") else ""
        st.markdown(text + detail)


class ProcessView:
    """Each search in its own box, filled step by step while it runs, and kept
    (in ``events``) so it can be shown again after the page refreshes."""

    def __init__(self) -> None:
        self.events: list[dict] = []
        self.box = None

    def begin(self, title: str) -> None:
        self.events.append({"title": title, "steps": [], "label": title})
        self.box = st.status(title, expanded=True, state="running")

    def step(self, stage: str, data: dict) -> None:
        if not self.events:
            self.begin("Search")
        event = self.events[-1]
        event["steps"].append((stage, data))
        with self.box:
            render_step(stage, data)
        if stage == "answered":
            table = QUESTION_OUTCOMES if data.get("question_mode") else OUTCOMES
            icon, short, _ = table.get(data.get("outcome"), table["failed"])
            if data.get("question_mode") and data.get("outcome") == "no_interaction":
                icon, short, _ = QUESTION_OUTCOMES["found"]
            event["label"] = f"{icon} {event['title']} → {short}"
            self.box.update(label=event["label"], expanded=False,
                            state="error" if data.get("outcome") == "failed" else "complete")


def show_process(events: list[dict]) -> None:
    """The steps of the last run, again, after the page refreshed."""
    if not events:
        return
    st.markdown(f"**How the answer was built** ({len(events)} step(s); open any to see what the AI did)")
    for event in events:
        with st.expander(event["label"]):
            for stage, data in event["steps"]:
                render_step(stage, data)


def progress_bar(view: ProcessView | None = None):
    bar = st.progress(0.0, text="Starting…")

    def update(done: int, total: int, label: str) -> None:
        bar.progress(done / total if total else 1.0, text=label)
        if view is not None and done < total:
            view.begin(f"{done + 1}/{total} · {label}")

    return bar, update


try:
    st.set_page_config(page_title="Medication review", page_icon="💊", layout="wide")
except Exception:  # already set by the deploy entry point (older Streamlit allows it once)
    pass

st.title("Medication review")
st.caption(
    "One view of every medicine a polymedicated patient takes, with each finding traced "
    "to its official source. The system informs; the clinician decides."
)

patients, problems = cached_patients()
catalogue = cached_catalogue()
(model_ready, model_message), (rules_ready, rules_message) = cached_status()
rule_data = None
if rules_ready:
    try:
        rule_data = cached_rule_data()
    except Exception as exc:  # unreadable codes file
        rules_ready, rules_message = False, f"the medicine codes could not be read ({exc})."

# Interactions: the live model (Groq), else the stored answers, else not checked.
stored = cached_stored_answers()
sheets = None  # technical sheets that can be searched (None: trust the medicine list)
if model_ready:
    interactions, review_fn, interaction_note = "live", None, None
    sheets = cached_index_sheets()
elif stored is not None:
    interactions, review_fn = "stored", stored_review(stored)
    sheets = stored.sheets
    interaction_note = (f"These answers were produced by the model on {stored.generated_at} and stored; "
                        "each quotation was verified against its section when it was produced.")
else:
    interactions, review_fn, interaction_note = "off", None, None
use_model = interactions != "off"
live = rules_ready or use_model

with st.sidebar:
    st.subheader("How it works")
    st.markdown(
        "1. Choose a patient.\n"
        "2. **Review current medicines**, or **ask about a new medicine** by typing a question.\n"
        "3. Watch each step of the AI, then read the report or download it as a PDF or a web page.\n\n"
        "Each report is also saved in the `output/` folder."
    )
    show_steps = st.toggle("Show each step of the AI", value=True,
                           help="Shows, for each search, the passages found in the technical sheet, "
                           "the ones kept, the model's answer and the checks, as it happens.")
    evaluation_ids = sorted(p.id for p, _ in patients if p.grupo == "evaluacion")
    show_evaluation = st.checkbox(
        f"Show evaluation patients ({', '.join(evaluation_ids)})" if evaluation_ids
        else "Show evaluation patients",
        value=False,
        help="Evaluation patients are kept aside for the final evaluation, so they are "
        "hidden by default. Tick this to add them to the patient list.",
    )
    st.markdown("**What this version checks**")
    st.markdown(
        ("✅" if rules_ready else "⚪") + " Duplicates, drug families and cascades  \n"
        + {"live": "✅ Interactions and typed questions (AI model called live, Groq)",
           "stored": f"⚪ AI model not called here: saved answers from {stored.generated_at if stored else ''}",
           "off": "⚪ Interactions"}[interactions]
    )
    if not live:
        st.caption("**Review current medicines** shows example results for now.")
    with st.expander("Technical details"):
        st.caption(f"Rules: {rules_message}." if rules_ready else f"Rules: not available. Reason: {rules_message}")
        st.caption("Model: connected." if model_ready else f"Model: not available here. Reason: {model_message}")
        if not model_ready:
            st.caption("Saved answers: " + (f"from {stored.generated_at}, {len(stored.answers)} searches."
                                            if stored else "none yet (data/interacciones_guardadas.json)."))
        if sheets is not None:
            marked = {n for n, e in catalogue.items() if e.ficha}
            st.caption(f"Technical sheets that can be searched: {len(marked & sheets)} of {len(catalogue)} medicines.")
    st.caption("Synthetic patients only.")
    for problem in problems:
        st.error(problem)

visible = [(p, s) for p, s in patients if show_evaluation or p.grupo != "evaluacion"]
visible.sort(key=lambda ps: (ps[0].grupo == "evaluacion", ps[1] == "demo", ps[0].id))
if not visible:
    st.error("No patient files found in data/pacientes.")
    st.stop()

by_id = {p.id: (p, s) for p, s in visible}


def patient_label(pid: str) -> str:
    p, source = by_id[pid]
    tags = (["demo"] if source == "demo" else []) + (["evaluation"] if p.grupo == "evaluacion" else [])
    extra = f"  ({', '.join(tags)})" if tags else ""
    return f"Patient {p.id} · {p.edad} years · {len(p.medicamentos)} medicines{extra}"


patient_id = st.selectbox("Patient", list(by_id), format_func=patient_label)
patient, _ = by_id[patient_id]

prescribers = {m.prescriptor for m in patient.medicamentos}
st.write(f"**{len(patient.medicamentos)} medicines** from **{len(prescribers)} prescribers**")
with st.expander("Medicines on file"):
    st.dataframe(
        [
            {"Medicine": m.nombre, "Dose": m.dosis, "Prescriber": m.prescriptor, "Reg. no.": m.nregistro}
            for m in patient.medicamentos
        ],
        hide_index=True,
    )

if interactions != "live":
    st.warning(
        f"**The AI model (Groq) is not being called here.** Reason: {model_message} "
        + ("Interactions come from answers the model saved earlier, and typed questions cannot be "
           "answered. " if stored else "")
        + "To call it live, run the app on the computer with the full set-up: "
        "`source ~/.venv/bin/activate`, then `python3 -m streamlit run app.py`."
    )
if interactions == "live":
    from src.config import DATABASE_DIR, MODEL_CACHE_DIR

    in_cloud = cloud_only_files(MODEL_CACHE_DIR, DATABASE_DIR)
    if in_cloud:
        st.warning(
            f"**{len(in_cloud)} file(s) of the search model are only in iCloud, not on this Mac**, so the "
            "first question can take several minutes while they download. In Finder, right-click the "
            "project folder and choose **Keep Downloaded** (Mantener descargado), then restart the app."
        )
if live:
    st.caption(what_runs(rules_ready, interactions))

tab_review, tab_check = st.tabs(["Review current medicines", "Ask about a new medicine"])

# --------------------------------------------------------------------------
# Tab 1: review the current medicines
# --------------------------------------------------------------------------
with tab_review:
    if live:
        if interactions == "live":
            n = planned_questions(patient, None, catalogue, sheets)
            st.caption(f"The AI model will be asked {n} question(s) for this patient, so it can take "
                       "a minute." if n else "No interaction searches are needed for this patient "
                       "(its medicines share the same active ingredient, or have no sheet here).")
    else:
        note = load_sample_findings().get(patient.id, {}).get("nota")
        if note:
            st.caption(f"Sample: {note}")

    just_ran = False
    if st.button("Review", type="primary", key="review"):
        bar, view, just_ran = None, ProcessView() if show_steps else None, True
        try:
            if live:
                bar, update = progress_bar(view)
                review = (live_review_with_steps(view.step) if view and interactions == "live"
                          else review_fn)
                checked = review_patient(
                    patient, catalogue, rule_data=rule_data, use_model=use_model,
                    review=review, sheets=sheets, progress=update, steps=view.step if view else None,
                )
                report = report_for(patient, checked)
            else:
                entry = load_sample_findings().get(patient.id, {})
                report = generate_report(
                    patient, entry.get("hallazgos", []),
                    checked_without_evidence=entry.get("pares_sin_informacion", []), sample=True,
                )
            st.session_state["result"] = {
                "patient_id": patient.id, "report": report, "files": saved_files(report),
                "steps": view.events if view else [],
                "unreachable": sum(1 for e in checked.log if e.get("reason") == "generation_failed") if live else 0,
            }
        except Exception as exc:  # show the problem on screen, not a stack trace
            st.session_state.pop("result", None)
            st.error(f"The review could not be completed: {exc}")
        finally:
            if bar is not None:
                bar.empty()

    result = st.session_state.get("result")
    if result and result["patient_id"] == patient.id:
        if result.get("unreachable"):
            st.error(f"The AI model (Groq) could not be reached for {result['unreachable']} search(es). "
                     "Check the internet connection and the GROQ_API_KEY in the .env file, then review again.")
        if not just_ran:
            show_process(result.get("steps", []))
        show_counts(result["report"], list(TYPE_LABELS.items()))
        show_report(result["report"], result["files"], key="review")
    else:
        st.info("Click **Review** to see the report for this patient.")

# --------------------------------------------------------------------------
# Tab 2: check a new medicine before prescribing it
# --------------------------------------------------------------------------
OUT_OF_SCOPE = (
    "This tool only answers questions about this patient's medicines, using their official technical "
    "sheets. It does not diagnose and does not answer other questions. Mention a medicine (for "
    "example ibuprofeno, Aldocumar or omeprazol), or ask about this patient's interactions."
)


def run_question(view, bar, update, question, sheet_entry):
    """Answer the typed question from one technical sheet (live model only)."""
    if interactions != "live":
        return None
    if view:
        view.begin(f"Your question · answering from the {sheet_entry.nombre} sheet")
    bar.progress(0.0, text=f"Answering your question from the {sheet_entry.nombre} sheet")
    try:
        answer = answer_typed_question(question_with_context(question, patient, catalogue),
                                       sheet_entry.nregistro, steps=view.step if view else None)
    except Exception as exc:  # search or model failure: shown, never "no information"
        answer = {"status": "error", "reason": type(exc).__name__}
    status = answer.get("status")
    outcome = status if status in ("found", "not_found") else "failed"
    detail = REASON_TEXT.get(answer.get("reason"), f"the search failed ({answer.get('reason')})")
    if view:
        view.step("answered", {"answer": answer, "outcome": outcome, "detail": detail, "question_mode": True})
    return {"status": status, "reason": answer.get("reason"), "response": answer.get("response"),
            "detail": detail if outcome == "failed" else None, "sheet": sheet_entry.nombre}


with tab_check:
    st.write(
        "Type a question about this patient's medicines, or about a medicine you're thinking of "
        "prescribing. The system finds the medicine in your question, answers it from the official "
        "technical sheet and checks it against the patient's medicines, quoting the text. "
        "It does not decide whether to prescribe, and it does not diagnose."
    )

    def has_sheet(entry) -> bool:
        return entry.ficha and (sheets is None or entry.nregistro in sheets)

    question = st.text_input(
        "Your question",
        placeholder="¿Puedo añadirle ibuprofeno a este paciente?",
        help="Mention the medicine by its brand or active ingredient, in Spanish or English "
        "(for example ibuprofeno, Aldocumar, omeprazole).",
    ).strip()
    recognised = find_medicines(question, catalogue, patient) if question else []
    new = [r for r in recognised if not r.already_taken and has_sheet(r.entry)]
    taken = [r for r in recognised if r.already_taken]
    # The patient's own medicines the question is about (same active ingredient).
    asked_keys = {normalise_text(i) for r in taken for i in r.entry.principios_activos}
    subset = [m for m in patient.medicamentos if m.nregistro in catalogue and asked_keys
              & {normalise_text(i) for i in catalogue[m.nregistro].principios_activos}]

    mode, nregistro = None, None
    if not question:
        pass
    elif new:
        mode = "new"
        if len(new) == 1:
            nregistro = new[0].entry.nregistro
            st.success(f"Medicine found in your question: **{new[0].entry.nombre}** (from “{new[0].keyword}”). "
                       "It will be checked against this patient's current medicines.")
        else:
            nregistro = st.radio(
                "Your question matches more than one medicine. Which one?",
                [r.entry.nregistro for r in new],
                format_func=lambda n: next(f"{r.entry.nombre} (from “{r.keyword}”)"
                                           for r in new if r.entry.nregistro == n),
            )
        if interactions == "live":
            n = planned_questions(patient, Medication(nregistro=nregistro, nombre=catalogue[nregistro].nombre,
                                                      dosis=NOT_SPECIFIED, prescriptor=NOT_SPECIFIED),
                                  catalogue, sheets)
            st.caption(f"The AI model will be asked {n + 1} question(s): your question, and {n} "
                       "search(es) for interactions with the current medicines.")
    elif subset:
        mode = "current"
        names = ", ".join(m.nombre for m in subset)
        st.info(f"Your question is about **{names}**, which the patient already takes. The AI will answer "
                "it from the technical sheet" + (" and check these medicines against each other." if len(subset) > 1
                                                 else "."))
    elif recognised:
        mode = "no_sheet"
        st.warning("The medicine in your question has no technical sheet in the system yet: "
                   + ", ".join(r.entry.nombre for r in recognised) + ".")
    elif asks_about_medicines(question):
        mode = "all"
        st.info("Your question names no medicine, so the system will check all of this patient's "
                "current medicines.")
    else:
        mode = "out_of_scope"
        st.warning(OUT_OF_SCOPE)

    with st.expander("Dose and prescriber (optional, for a new medicine)"):
        c1, c2 = st.columns(2)
        dose = c1.text_input("Dose", placeholder="400 mg cada 8 horas")
        prescriber = c2.text_input("Prescriber", placeholder="Dra. Pérez (Atención Primaria)")
    with st.expander("Medicines the system knows"):
        st.markdown("\n".join(
            f"- {e.nombre} ({', '.join(e.principios_activos)})" + ("" if has_sheet(e) else " · sheet not available")
            for e in sorted(catalogue.values(), key=lambda e: e.nombre.casefold())))

    just_ran = False
    if st.button("Ask", type="primary", key="check"):
        if not question:
            st.info("Type a question first, for example: ¿Puedo añadirle ibuprofeno a este paciente?")
        elif mode in ("out_of_scope", "no_sheet") or (mode == "new" and nregistro is None):
            pass  # the message above already says why nothing runs
        else:
            view, just_ran = (ProcessView() if show_steps else None), True
            bar, update = progress_bar(view)
            try:
                if mode == "new":
                    entry = catalogue[nregistro]
                    proposed = Medication(nregistro=nregistro, nombre=entry.nombre,
                                          dosis=dose.strip() or NOT_SPECIFIED,
                                          prescriptor=prescriber.strip() or NOT_SPECIFIED)
                    question_answer = run_question(view, bar, update, question, entry)
                    review = live_review_with_steps(view.step) if view and interactions == "live" else review_fn
                    checked = check_new_medicine(
                        patient, proposed, catalogue, rule_data=rule_data, use_model=use_model,
                        review=review, sheets=sheets, progress=update, steps=view.step if view else None,
                    )
                    report = report_for(patient, checked, proposed, question=question,
                                        question_answer=question_answer)
                    labels = [("duplicado", "Same ingredient"), ("interaccion", "Interactions found"),
                              ("checked_without_evidence", "Nothing found"), ("could_not_check", "Could not check")]
                else:
                    scope = patient if mode == "all" else patient.model_copy(update={"medicamentos": subset})
                    if mode == "current":
                        sheet = next((catalogue[m.nregistro] for m in subset if has_sheet(catalogue[m.nregistro])),
                                     None)
                        question_answer = (run_question(view, bar, update, question, sheet) if sheet else
                                           {"status": "note", "detail": "Its technical sheet is not available here."})
                        note = (f"Your question is about {', '.join(m.nombre for m in subset)}, which the patient "
                                "already takes, so this report covers only "
                                + ("these medicines" if len(subset) > 1 else "this medicine")
                                + ". Use Review current medicines to check all of them.")
                    else:
                        question_answer = {"status": "note", "detail": "Your question names no medicine, so all of "
                                           "this patient's current medicines were checked below."}
                        note = None
                    review = live_review_with_steps(view.step) if view and interactions == "live" else review_fn
                    checked = review_patient(
                        scope, catalogue, rule_data=rule_data, use_model=use_model,
                        review=review, sheets=sheets, progress=update, steps=view.step if view else None,
                    )
                    report = report_for(scope, checked, question=question, question_answer=question_answer,
                                        scope_note=note)
                    labels = list(TYPE_LABELS.items())
                unreachable = sum(1 for e in checked.log if e.get("reason") == "generation_failed") + (
                    1 if (question_answer or {}).get("reason") == "generation_failed" else 0)
                st.session_state["check_result"] = {
                    "patient_id": patient.id, "question": question, "report": report, "labels": labels,
                    "files": saved_files(report), "log": checked.log,
                    "steps": view.events if view else [], "unreachable": unreachable,
                }
            except Exception as exc:  # show the problem on screen, not a stack trace
                st.session_state.pop("check_result", None)
                st.error(f"The check could not be completed: {exc}")
            finally:
                bar.empty()

    checked_result = st.session_state.get("check_result")
    # Only the answer to the question on screen (a new question hides the old answer).
    if checked_result and checked_result["patient_id"] == patient.id and checked_result.get("question") == question:
        if checked_result.get("unreachable"):
            st.error(f"The AI model (Groq) could not be reached for {checked_result['unreachable']} question(s). "
                     "Check the internet connection and the GROQ_API_KEY in the .env file, then ask again.")
        if not just_ran:
            show_process(checked_result.get("steps", []))
        show_counts(checked_result["report"], checked_result["labels"])
        show_report(checked_result["report"], checked_result["files"], key="check")
