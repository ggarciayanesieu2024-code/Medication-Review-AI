# Person 5 - Interface, report and evaluation

Last updated: 24 November 2026 (typed questions; the screen shows each step of the AI as it runs; a shared link that calls Groq live. Before that, fixes from Lu's review: one result per pair of medicines, answers that describe no interaction, duplicates not searched against each other, more specific questions, medicine selector, header and start-up).

## Status

| Deliverable | Status |
| --- | --- |
| 1. Streamlit screen (`app.py`) | Done. Two tabs, **Review current medicines** and **Ask about a new medicine** (a typed question), both using Person 2's rules and Person 3's model (Groq, called live) when available, and showing each step of the AI. |
| 2. Report (`src/informe.py`, `src/exportar.py`) | Done. Saves PDF and web page to `output/`. |
| 3. Safety cases and report tests | Done. `tests/fixtures/safety_cases.json` and the safety tests in `tests/test_informe.py`; results below. |
| 4. 20 evaluation questions (`evaluacion/preguntas.json`) | Pending. Needs the shared CIMA file to check expected answers. |
| 5. Metrics (`evaluacion/`) | In progress (Lu): `evaluacion/evaluar.py` scores the evaluation patients with `review_patient` and the stored answers. It relies on `CheckResult.log` and the interaction findings staying in the same order, which `tests/test_revision.py` checks. |
| 6. Evaluation write-up | Pending. |

## Run the screen

From the project root, **with the environment active** (otherwise the model's libraries are not found and the screen falls back to the saved answers):

```bash
source ~/.venv/bin/activate
python3 -m streamlit run app.py
```

The sidebar must say "✅ Interactions and typed questions (AI model called live, Groq)". If the AI model is not being called, a yellow box at the top of the page says so and why.

For the demo, start it with `HF_HUB_OFFLINE=1 python3 -m streamlit run app.py`: the search model then loads from the computer without checking the internet. Keep the project **outside** iCloud-synced folders (Desktop, Documents): iCloud can remove the local copy of the search model and the index, and the screen then waits for them to download. The screen warns when that happens (`cloud_only_files`).

Terminal must stay open while the app is in use; closing it (or Ctrl+C) stops the app.

Choose a patient, then use one of the two tabs. **Download the report** offers a **PDF** (opens in Preview, Adobe Reader or any browser) and a **web page** (opens in any browser, with a "Print or save as PDF" button). Both are also saved in `output/`.

Evaluation patients are hidden unless **Show evaluation patients (E1, E2, E3, E4, E5, EVAL_P4)** is ticked in the sidebar.

### What each part needs

The sidebar shows **What this version checks**; **Technical details** gives the reason when a part is not available and how many technical sheets can be searched.

| Part | Gives | Uses, in this order |
| --- | --- | --- |
| Rules (Person 2, `src/reglas.py`) | Duplicates, same drug family (ATC), prescribing cascades | 1. Nomenclator codes from `data/processed/prescriptions.json`. 2. If that file is missing, the ATC codes and ingredient names in `data/catalogo_medicamentos.json` |
| Interactions (Person 3, `src.rag.review_interaction`) | What each technical sheet says about the other medicine, with the verified quotation | 1. The live model: full `requirements.txt`, the shared CIMA file saved as `data/processed/fragmentos_cima.json` and indexed with `python -m src.indice`, `GROQ_API_KEY` in `.env`. 2. Otherwise the stored answers in `data/interacciones_guardadas.json` |

What happens when a part is missing:
- **No rules** (only if `src/reglas.py` does not load): duplicates fall back to comparing ingredient names, and drug family and cascades show as **Not checked**.
- **No model and no stored answers:** interactions show as **Not checked**.
- **Neither part:** **Review current medicines** shows the sample findings under a **Sample data** banner.

The report never says "None found" for something that was not checked.

## The two tabs (`src/revision.py`)

**Review current medicines** (`review_patient`) checks every pair of the patient's medicines.

**Ask about a new medicine**: the prescriber types a question, in Spanish or English, for example "¿Puedo añadirle ibuprofeno?". Then:
1. `find_medicines` finds the medicine in the question by its brand ("Ibudol"), its product name ("Atorvastatina Stada") or its active ingredient ("ibuprofeno", "omeprazole"). An ingredient with several products (ibuprofen: Ibudol and Geloprofen) gives a choice; a medicine the patient already takes is offered last. Only medicines whose sheet can be searched are used.
2. `answer_typed_question` sends the question to Person 3's `answer_question` pipeline on that medicine's technical sheet (all sections). The answer, with its verified quotation, opens the report under "Your question". It is checked for forbidden wording like any generated text. Only the live model answers typed questions.
3. `check_new_medicine` checks the medicine against the patient's current medicines, as before, and keeps only findings that involve it.

The question is sent with the patient's age and current active ingredients (`question_with_context`), and answered from the single closest passage of the sheet (three whole sections can be more than Groq's free plan accepts in one request). If Groq does not answer, the screen waits 15 seconds and asks once more.

What the screen does with other questions:
- **About medicines the patient already takes** ("¿Qué interacción hay entre sertralina y warfarina?", "¿Debería dejar de tomar Aldocumar?"): answers from that medicine's sheet and checks only those medicines against each other. The report says what it covers.
- **About the patient's medicines with no name** ("¿Hay interacciones?", `asks_about_medicines`): reviews all the current medicines.
- **Anything else** ("¿Qué enfermedad tiene?", "¿Cuál es la capital de Francia?"): a message that the tool only answers questions about the patient's medicines and does not diagnose. Groq is not called.
- **Empty question:** asks for one. **Groq not reachable:** a red message to check the internet and the key.

Tested on 25 November with the live model (the group's test list): sertraline + warfarin in E3 cites sheet 59718, section 4.5; "¿Debería dejar de tomar Aldocumar?" gives no recommendation and says decisions stay with the prescriber; the diagnosis and off-topic questions are refused; patient A's "¿Hay interacciones?" reports the duplicate and never says "safe".

### Showing each step of the AI

With **Show each step of the AI** on (sidebar, on by default), each search gets its own box that fills in while it runs, then closes with its result (🔶 interaction described, ⚪ nothing found or no interaction described, ⚠️ could not be checked):
1. **Search**: the closest passages of the sheet (section 4.5 for interactions), with their similarity.
2. **Keep**: which passages mention the other medicine. If none does, the model is not asked.
3. **Ask the AI model** (Groq) with only those passages.
4. **The model's answer** and the **checks**: no wording that tells someone to start, stop or change a treatment; every quotation word for word in the sheet. A rejected answer is shown, with why it was rejected.
5. **Result**: what goes into the report.

`live_review_with_steps` runs `src.rag.review_interaction`'s own functions in the same order (`prepare_interaction_search`, then `run_prepared_request`), so the answer is the same; it only reports each step. To show the model's answer even when the checks reject it, it keeps a copy of what `llm_medication_review` returned (nothing else in `src/rag.py` changes). After the page refreshes (for example after a download), the steps are listed again under "How the answer was built". The screen never says whether the medicine can or cannot be prescribed: it shows what the rules and the technical sheets say, and the prescriber decides. Cascade texts say whether the new medicine would complete a cascade or start one.

For interactions, each pair is searched in both directions, because `review_interaction` searches one sheet for one ingredient:
- **Order:** one medicine's sheet is searched for the other's ingredient, then the other way round.
- **Combination medicines** (for example amoxicillin/clavulanic acid) are searched once per ingredient.
- **Each search once:** medicines with the same ingredients (for example two metformin brands in DEMO_D) are searched together, so the same sheet is never searched twice for the same ingredient.
- **Same ingredient:** medicines that share an ingredient are a duplicate, so they are not searched for interactions with each other. The report lists them under "Not searched for interactions with each other".
- **Sheet not available:** a medicine whose sheet cannot be searched here (not in the CIMA file, or no stored answers for it) is only looked for in the other sheet. The report says so once per medicine, and the pair line says "only the X sheet was searched". The **Check a new medicine** list only offers medicines whose sheet can be searched.

Each model answer is sorted into one of four kinds:
- `found` with a description of an effect: an interaction finding with the verified quotation.
- `found`, but the description only says the sheet describes **no** interaction (for example "el amlodipino no afecta la farmacocinética de la atorvastatina"): counted as "no interaction found", and the pair line says "section 4.5 of the X sheet mentions this combination but describes no relevant interaction". Only clear wording counts (`describes_no_interaction`): if the description also mentions any effect ("puede", "aumenta", "riesgo", "no se puede excluir"…), it stays an interaction, because hiding a real one is the worse mistake. In the stored answers this applies to 3 of the 23 found answers (amlodipine with atorvastatin and with warfarin, atorvastatin with amlodipine).
- `not_found`: nothing found.
- `rejected`, `error` or a failed search: could not be checked, never "nothing found".

The report then gives **one result per pair of medicines**, whichever direction gave it:
1. **Interaction** if either sheet describes one. The pair gets one heading (for example "4.1 Ibudol + Aldocumar") with the quotation from each sheet that describes it, and one question.
2. Otherwise **could not be completed** if a search failed (the line says which sheet and why, and what the other sheet gave).
3. Otherwise **no interaction found**, with the note that this does not mean the combination is safe.

The counts on screen and in the summary are counts of pairs. Medicines missing from the nomenclator data or the medicine list also go to **Checks that could not be completed**.

The follow-up questions name the medicines, the prescribers and, for interactions, the sheet and section that describe it. Duplicate questions name the shared ingredient, and cascade questions start with the two medicines involved.

`CheckResult.log` keeps one line per search (sheet, ingredient, status, reason). Its "found" lines and the interaction findings are in the same order, one to one; answers that describe no interaction are logged as `not_found` with reason `no_interaction_described`.

### Stored model answers (for the shared link)

The shared link cannot run the model (no CIMA file, no key, no heavy libraries). Instead, someone with the model set up runs, once:

```bash
python -m src.guardar_interacciones
```

It asks the model every search any patient or new medicine can need (each technical sheet, searched for every other ingredient: 394 for the 22 medicines in the list) and saves the answers in `data/interacciones_guardadas.json`. Then upload that file to GitHub (and **Sync fork** for the link).

- **Rate limit:** questions that reach the model are spaced 2 seconds apart (`--pause`) to stay under Groq's free-tier limit. Searches with no matching fragment do not call the model.
- **What is kept:** found, not found and rejected answers. Errors such as the API limit are not saved, so running the command again only retries those.
- **Sheets not in the CIMA file are skipped:** searching them would always give "nothing found", which would be stored as if the sheet had been read. The script lists them and prints the `src/parse_cima.py` command (with every registration number) that adds them; then run `python -m src.indice` and the script again.
- **When to rerun:** after medicines or sheets are added, run it again as it is: it only asks the missing searches. Use `--start-over` only if the text of sheets already stored has changed.

The screen uses the stored answers whenever the live model is not available, and the report says when they were produced. They are the model's own verified answers, not sample data. Each answer also keeps the sections it was based on (`sources`), which the metrics script (deliverable 5) can use for retrieval success.

### The medicine list

`data/catalogo_medicamentos.json` lists every medicine in the patient files with:
- its active ingredients, in Spanish as the sheets write them (the interaction search looks for these names),
- whether CIMA has its technical sheet (`ficha`; all 22 since 23 November), and
- its WHO ATC code (`atc`), which the rules use when the nomenclator file is missing.

Which sheets can actually be searched depends on the computer: with the live model, the sheets in `data/processed/fragmentos_cima.json`; with stored answers, the sheets that have stored answers.

`tests/test_revision.py` checks that every patient medicine is in the list. On a computer with the CIMA file, it also checks that every medicine marked with a sheet is in that file. Registration 87970 is in the CIMA file but not in any patient file, so it is not in the list.

### Limitations

- The interaction search looks for the ingredient's name. A sheet that only names the group ("AINE", "anticoagulantes orales") is not found from that side, although the other direction often finds it.
- `Finding.cita` holds one citation, so when the model gives several, the report shows the first.
- Answers that describe no interaction are recognised from their wording. Wording the list does not know stays an interaction (the safe side); Person 3's prompt could also return `not_found` for them.
- A review asks the model up to two searches per pair of medicines (more for combination medicines), each search once. The screen says how many before you start, and a progress bar shows each search. Groq's free tier limits requests per minute.
- The first visit to the shared link after a while takes about a minute: the free hosting puts the app to sleep and has to start it again. After that, patients, the medicine list and the stored answers are loaded once and reused.

### Shared link that calls Groq live (`deploy_live/`)

A second Community Cloud app, with **Main file path** `deploy_live/streamlit_app.py` and Python 3.12, calls the AI model live:
- **Packages:** `deploy_live/requirements.txt` (Groq, ChromaDB, sentence-transformers with CPU-only PyTorch).
- **Key:** in the app's **Settings → Secrets**: `GROQ_API_KEY = "..."`. It is never put in GitHub. Everyone who uses the link uses this key's Groq quota.
- **Technical sheets and index:** on the first start, the entry point downloads the sheets of every medicine in the list from CIMA with `src/parse_cima.py` (or uses `deploy_live/fragmentos_cima.json` if someone uploads it) and builds the index with `src/indice.py`. This takes a few minutes once; later visits reuse it until the app goes to sleep.

It could not be tested from here. If it fails, the app's logs (**Manage app**) show why, and the laptop remains the reliable way to run the demo.

### Hosted demo with saved answers (Streamlit Community Cloud)

The shared link is deployed from Gabi's fork (`ggarciayanesieu2024-code/Medication-Review-AI`, branch `main`), because deploying needs admin rights on the repository, which only the owner has. Click **Sync fork** on GitHub to bring in new changes.

The entry point (**Main file path**) is `deploy/streamlit_app.py`. It runs `app.py` but makes Community Cloud install only `deploy/requirements.txt` (Streamlit, Pydantic, python-dotenv, ReportLab) instead of the full list with PyTorch.

On the link:
- **Rules:** run with the medicine list's ATC codes, once `src/reglas.py` loads.
- **Interactions:** come from the stored answers, once `data/interacciones_guardadas.json` is on GitHub.
- **Live questions:** asking the model in real time (and anything not stored) needs a laptop with the full setup.

## Safety cases (deliverable 3)

`tests/fixtures/safety_cases.json` holds 29 unsafe sentences (English and Spanish) that tell someone to start, stop or change a treatment, and 14 safe sentences that inform or ask. The tests in `tests/test_informe.py` check four things:

1. The shared `FORBIDDEN_PHRASES` (`src/config.py`) catches each unsafe sentence, ignoring case, accents and extra spaces.
2. It lets each safe sentence through, including medicine names such as "polvo para suspensión oral" and the report's own questions.
3. When generated text is unsafe, the report withholds it and flags it, and the disclaimer still appears in the Markdown and the web page.
4. The report and `src/rag.py` normalise text the same way. This test only runs where the model libraries are installed.

### Results with the current list

The current list has 10 exact phrases and catches **14 of the 29** unsafe sentences. It blocks none of the safe ones. The 15 it misses are marked `known_gap` and run as expected failures (XFAIL), so the suite stays green. They are mostly other ways of saying the same thing:
- "Discontinue warfarin" and "Lower the dose of amlodipine"
- infinitives such as "suspender", "dejar de tomar" and "reducir la dosis"
- "Ajustar la dosis de warfarina según el INR", which Person 3 saw in a live answer

Each gap test is strict, so when the list catches one of them, that test fails with XPASS as a reminder to set `known_gap` to `false`.

### Suggested additions for Person 4

These 18 phrases were checked against all the examples, the cascade questions in `data/cascadas.json` and the report's own wording:

`discontinue`, `lower the dose`, `halve the`, `do not take`, `instead of`, `replace ` (with the space), `ajustar la dosis`, `ajuste la dosis`, `suspender`, `dejar de tomar`, `cambie a ` (with the space), `sustituya`, `retire la`, `retire el`, `iniciar tratamiento`, `inicie tratamiento`, `reducir la dosis`, `aumentar la dosis`

With them, the list catches **28 of 29** unsafe sentences and still blocks no safe text. Adding `stop ` (with the space) catches the last one ("Stop ibuprofen…"). It is the broadest phrase, so it may also block sentences such as "the patient stopped…" in future texts.

Phrases to avoid, because they block safe text:
- `prescribe` (it also matches "prescribed by", used in every duplicate finding)
- `ajuste de dosis` (it matches dose information quoted from section 4.2)

### The trade-off with quoted text

`src/rag.py` checks the forbidden phrases in the model's description **and** in the literal quotations from the technical sheets. A quotation is the official text, and sections 4.2 and 4.4 often contain wording like "debe suspenderse el tratamiento". The longer the list, the more real answers, including the dosage and contraindication questions in the evaluation, will be rejected because of their quotation. Checking only the description, as the report does, would avoid that. The safe examples marked `in_source_text` show the kind of sentences involved.

## Files

| Path | What it is |
| --- | --- |
| `app.py` | Streamlit screen: patient dropdown, system status, the two tabs (review; typed question), each step of the AI, report and downloads |
| `deploy_live/streamlit_app.py`, `deploy_live/requirements.txt` | Entry point and packages for a shared link that calls Groq live |
| `src/revision.py` | Runs the rules and the model (live or stored) for both tabs; status checks; medicine list |
| `src/guardar_interacciones.py` | One-time script that stores the model's answers for the shared link |
| `data/interacciones_guardadas.json` | The stored answers (created by the script on 23 November: 305 searches for the first 17 sheets) |
| `src/informe.py` | Builds the report from `Patient` + `Finding` objects (and a proposed medicine for a check); `FOOTER`; forbidden-phrase check |
| `src/exportar.py` | Turns the report into a web page (`render_html`) and a PDF (`render_pdf`, ReportLab) |
| `data/catalogo_medicamentos.json` | Medicines the screen can use, their active ingredients and whether the system has their sheet |
| `data/demo/pacientes_demo.json` | Five extra development patients for the demo (DEMO_D to DEMO_H) |
| `data/demo/hallazgos_ejemplo.json` | Sample findings, used only when neither the rules nor the model are available |
| `tests/test_revision.py` | Both tabs with a stand-in model and Person 2's real rules (with codes written in the test) |
| `tests/test_informe.py` | Footer, structure, download and safety tests; development and evaluation patients kept apart |
| `tests/fixtures/safety_cases.json` | Unsafe sentences that must be blocked (with known gaps) and safe ones that must pass |

The PDF needs `reportlab`. It is in `deploy/requirements.txt`, but the main `requirements.txt` (its owner's file) still needs it; until then, run `pip install reportlab` once. Adding `output/` to `.gitignore` keeps saved reports out of Git.

## What the report shows

1. Medicines grouped by prescriber, in the order they appear in the patient file. In a check, the proposed medicine is listed separately as "not yet prescribed"; an empty dose or prescriber is left out of the header.
2. Duplicate active ingredients (`tipo: duplicado`)
3. Same therapeutic group (`tipo: advertencia_atc`)
4. Possible interactions (`tipo: interaccion`), one heading per pair of medicines, with medicine, registration number, section and literal quotation from each sheet that describes it; then the pairs checked with no interaction found, and the pairs not searched against each other because they share an ingredient
5. Possible prescribing cascades (`tipo: cascada`), as hypotheses to review, with the table's sources
6. Checks that could not be completed (only when there are any)
7. Questions: each finding's `pregunta_medico`, plus a general question about other medicines and supplements
8. The mandatory footer, always last. The PDF also prints it at the bottom of every page.

Descriptions and questions are checked again with the shared `FORBIDDEN_PHRASES` (same normalisation as `src/rag.py`). Text that matches is withheld and counted. Literal quotations are shown unchanged.

## Sample data and demo patients

The sample findings are placeholders, not expected results, and their quotations are not CIMA text. They are only shown when neither the rules nor the model are available, under a "Sample data" banner.

The demo patients use only medicines that appear in the group's patient files. They are development data, not evaluation data. Lucía should review them; they can move to `data/pacientes/` if the group agrees.

| Patient | What it shows |
| --- | --- |
| A, B, C | Lucía's development patients: duplicate paracetamol; warfarin + antibiotic; nothing to flag |
| DEMO_D | Metformin under two names from two doctors |
| DEMO_E | Warfarin with paracetamol and omeprazole from other doctors |
| DEMO_F | Possible cascade C07: ibuprofen, then amlodipine from another doctor |
| DEMO_G | Five medicines from four doctors, two possible interactions |
| DEMO_H | Carmen's story: ibuprofen, warfarin, paracetamol and pantoprazole from three doctors |

### Development and evaluation patients

Development patients (A, B, C and DEMO_*) are used to build and check the screen, the report, the prompts and the rules. Evaluation patients (EVAL_P4 and E1 to E5) are kept aside, so that the final results measure the system on cases it was not tuned on. They are hidden in the screen unless **Show evaluation patients** is ticked, and the report tests do not use them.

`test_development_patients_do_not_copy_evaluation_cases` checks that no development patient contains:
- an evaluation patient's whole medicine list, or
- a pair whose result an evaluation patient checks (from `expected_result`).

The test compares registration numbers, so it would miss the same scenario with different brands. The demo patients were therefore also chosen to avoid the evaluation scenarios: the ibuprofen duplicate (E1), amlodipine with furosemide (E2), sertraline with warfarin (E3), the two statins (E4) and levothyroxine with a proton pump inhibitor (E5).

## Open points for the group

- **Add the 5 new sheets to the stored answers (#6).** The medicine list now marks Januvia, Geloprofen, Clopidogrel, Combiprasal and Atorvastatina Stada as having a sheet, but the CIMA file and the stored answers only have the first 17. On the laptop with the model: run `src/parse_cima.py` with all 23 numbers, `python -m src.indice`, then `python -m src.guardar_interacciones` (without `--start-over`). Until then E4 and E5 show those sheets as "not available in this version".
- **Accents lost in `data/pacientes/evaluacion_pacients.json`:** five names have `?` instead of accented letters ("Losart?n", "pel?cula", "c?psulas", "s?dica"), probably from saving the file with the wrong encoding. They were fixed in the medicine list and the demo patients; EVAL_P4's file is its owner's.
- **Old copy of the stored answers:** `interacciones_guardadas.json` at the top of the repository is an earlier copy (304 answers). The app reads `data/interacciones_guardadas.json`; the top-level copy can be deleted.
- **Rejected Aldocumar answers (#3, Person 4):** the Aldocumar sheet's answers for ibuprofen, omeprazole, paracetamol and simvastatin were rejected as unverifiable quotations. The report still shows those pairs when the other medicine's sheet describes the interaction.
- **Group names (#1, Person 3):** a sheet that only names the group ("inhibidores de la bomba de protones", "AINE") is not found from that side.
- **`FORBIDDEN_PHRASES` (#9, Person 4):** catches 14 of the 29 unsafe examples. See "Suggested additions for Person 4" above, and decide whether quotations should be checked too.
- **`tests/test_reglas.py` uses old registration numbers.** `DRUG_INFO` still has 77758 and 66337, which the patient files replaced with 68339 and 65222, so the patient A and B tests fail with a KeyError. Updating those two numbers fixes them.
- **`tests/test_modelos.py::test_shared_cascade_data` fails.** `data/cascadas.json` now has `sources` and `cascades`, but `CascadeCase` in `src/modelos.py` still expects the old list.
- **ATC/statin case:** E4 expects no duplicate and no interaction. With Person 2's rules, E4 gets a same-family warning (C10AA). `evaluar.py` reports it but does not score it; agree whether it is expected.
- **Two formats for expected results:** `EVAL_P4` has `resultado_esperado`, and E1 to E5 have `expected_result`. `evaluar.py` reads both.
- **Keep the evaluation fair:** do not tune prompts on the medicine pairs that evaluation patients E1 to E5 check (for example sertraline with warfarin).
