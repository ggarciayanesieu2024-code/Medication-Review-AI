"""Tests for src/revision.py: the checks behind both tabs of the screen.

A stand-in replaces src.rag.review_interaction, so no search index or Groq key
is needed (Person 3's own tests cover the real pipeline). The rules tests use
Person 2's real src/reglas.py with nomenclator codes written in the test, so
they do not need data/processed/prescriptions.json.
"""
import json

import pytest

from src import revision
from src.config import FRAGMENTS_FILE, PATIENTS_DIR, PROJECT_ROOT
from src.informe import FOOTER, generate_report
from src.modelos import Medication, Patient
from src.revision import (
    all_questions,
    check_new_medicine,
    load_catalogue,
    load_rule_data,
    load_stored_answers,
    model_status,
    planned_questions,
    review_patient,
    rules_status,
    save_answers,
    stored_review,
)

CATALOGUE = load_catalogue()


def _patient(meds, pid="T"):
    return Patient(id=pid, edad=80, grupo="desarrollo", medicamentos=[
        {"nregistro": n, "nombre": CATALOGUE[n].nombre, "dosis": "1 al día", "prescriptor": who}
        for n, who in meds
    ])


def _proposed(nregistro, prescriber="Dra. Pérez (Atención Primaria)"):
    return Medication(nregistro=nregistro, nombre=CATALOGUE[nregistro].nombre,
                      dosis="1 al día", prescriptor=prescriber)


def _found(nregistro):
    return {"status": "found", "reason": None, "response": {
        "status": "found",
        "description": "La ficha describe un posible aumento del riesgo de sangrado.",
        "citations": [{"nregistro": nregistro, "seccion": "4.5",
                       "literal_quote": "puede aumentar el riesgo de hemorragia en pacientes tratados"}],
    }}


class FakeModel:
    """Records every question and answers from a table; default is not_found."""

    def __init__(self, answers=None):
        self.answers = answers or {}
        self.calls = []

    def __call__(self, nregistro, ingredient):
        self.calls.append((nregistro, ingredient))
        answer = self.answers.get((nregistro, ingredient), "not_found")
        if isinstance(answer, dict):
            return answer
        if isinstance(answer, Exception):
            raise answer
        if answer == "found":
            return _found(nregistro)
        if answer in ("rejected", "error"):
            reason = "forbidden_phrase" if answer == "rejected" else "generation_failed"
            return {"status": answer, "reason": reason, "response": None}
        return {"status": "not_found", "reason": "no_evidence", "response": None}


# ---------------------------------------------------------------- medicine list

def _all_patient_medicines():
    paths = sorted(PATIENTS_DIR.glob("*.json")) + [PROJECT_ROOT / "data" / "demo" / "pacientes_demo.json"]
    for path in paths:
        data = json.loads(path.read_text(encoding="utf-8"))
        for patient in data if isinstance(data, list) else [data]:
            yield from patient["medicamentos"]


def test_every_patient_medicine_is_in_the_list():
    missing = {m["nregistro"] for m in _all_patient_medicines()} - set(CATALOGUE)
    assert not missing, f"add these registration numbers to data/catalogo_medicamentos.json: {missing}"


def test_every_entry_has_an_ingredient():
    for entry in CATALOGUE.values():
        assert entry.principios_activos and all(i.strip() for i in entry.principios_activos)


def test_every_entry_has_an_atc_code():
    for entry in CATALOGUE.values():
        assert entry.atc and all(len(code) == 7 for code in entry.atc), entry.nombre


def test_list_matches_the_shared_cima_file():
    """Runs only on a computer that has the shared CIMA file."""
    if not FRAGMENTS_FILE.exists():
        pytest.skip("shared CIMA file not in data/processed/")
    fragments = json.loads(FRAGMENTS_FILE.read_text(encoding="utf-8"))
    with_sheet = {f["nregistro"] for f in fragments}
    marked = {n for n, e in CATALOGUE.items() if e.ficha}
    assert marked <= with_sheet, (
        f"marked as having a sheet but not in the CIMA file: {sorted(marked - with_sheet)}. "
        "Run src/parse_cima.py with these numbers too, then src/indice.py."
    )


# ---------------------------------------------------------------- new medicine, model part

# Every sheet marked in the medicine list, except Januvia's: used to test what
# happens when a sheet is not available.
WITHOUT_JANUVIA = {n for n, e in CATALOGUE.items() if e.ficha} - {"07383002"}
IBUDOL, ALDOCUMAR = CATALOGUE["88372"].nombre, CATALOGUE["63064"].nombre


def test_both_directions_are_asked_and_the_pair_is_shown_once():
    patient = _patient([("63064", "Dr. Gómez (Cardiología)")])  # warfarin
    model = FakeModel({("88372", "warfarina"): "found"})          # Ibudol's sheet mentions warfarin
    result = check_new_medicine(patient, _proposed("88372"), CATALOGUE, review=model)

    assert model.calls == [("88372", "warfarina"), ("63064", "ibuprofeno")]
    [finding] = result.findings
    assert finding.tipo == "interaccion" and finding.cita.nregistro == "88372"
    assert "Dr. Gómez (Cardiología)" in finding.pregunta_medico
    assert f"technical sheet of {IBUDOL} (section 4.5)" in finding.pregunta_medico
    # found in one direction: the pair is NOT also listed as "nothing found"
    assert result.checked_without_evidence == [] and result.could_not_check == []
    [group] = result.interaction_groups
    assert group.title == f"{IBUDOL} + {ALDOCUMAR}" and group.findings == [finding]


def test_found_in_both_directions_is_one_pair_with_both_quotations():
    patient = _patient([("63064", "Dr. Gómez")])
    model = FakeModel({("88372", "warfarina"): "found", ("63064", "ibuprofeno"): "found"})
    result = check_new_medicine(patient, _proposed("88372"), CATALOGUE, review=model)
    [group] = result.interaction_groups
    assert [f.cita.nregistro for f in group.findings] == ["88372", "63064"]
    assert "technical sheets of" in group.question


def test_pair_with_nothing_found_in_either_sheet_is_counted_once():
    patient = _patient([("63064", "Dr. Gómez")])
    result = check_new_medicine(patient, _proposed("88372"), CATALOGUE, review=FakeModel())
    assert result.checked_without_evidence == [f"{IBUDOL} + {ALDOCUMAR}"]


def test_answer_that_describes_no_interaction_is_not_an_interaction():
    negative = {"status": "found", "reason": None, "response": {
        "status": "found",
        "description": "Según la información, el amlodipino no afecta la farmacocinética de la atorvastatina.",
        "citations": [{"nregistro": "65461", "seccion": "4.5", "literal_quote":
                       "En estudios clínicos de interacción, amlodipino no afectó la farmacocinética de atorvastatina"}],
    }}
    patient = _patient([("69534", "Dr. López")])  # atorvastatin
    result = check_new_medicine(patient, _proposed("65461"), CATALOGUE,
                                review=FakeModel({("65461", "atorvastatina"): negative}))
    assert result.findings == [] and result.interaction_groups == []
    [line] = result.checked_without_evidence
    assert "section 4.5 of the Amlodipino Cinfa 10 mg comprimidos EFG sheet mentions this combination" in line
    assert "describes no relevant interaction" in line
    assert result.log[0]["status"] == "not_found"
    assert result.log[0]["reason"] == "no_interaction_described"


def test_shared_ingredient_is_searched_once_and_not_against_itself():
    # Dianben and Metformina Aenova are both metformin (DEMO_D).
    patient = _patient([("55211", "Dra. Medina"), ("76578", "Dr. Ruiz"), ("67729", "Dr. López")])
    model = FakeModel()
    result = review_patient(patient, CATALOGUE, use_model=True, review=model)
    assert sorted(model.calls) == [("55211", "losartán"), ("67729", "metformina"), ("76578", "losartán")]
    assert planned_questions(patient, None, CATALOGUE) == 3
    [same] = result.same_ingredient
    assert "Dianben" in same and "Metformina Aenova" in same and "metformina" in same
    [pair] = result.checked_without_evidence
    assert pair.startswith("Dianben 850 mg comprimidos / Metformina Aenova")


def test_current_medicine_without_sheet_is_searched_in_one_direction():
    patient = _patient([("07383002", "Dra. Medina (Atención Primaria)")])  # Januvia
    model = FakeModel()
    result = check_new_medicine(patient, _proposed("55211"), CATALOGUE, review=model, sheets=WITHOUT_JANUVIA)
    assert model.calls == [("55211", "sitagliptina")]
    [note] = result.could_not_check
    assert "Januvia" in note and "not available in this version" in note
    [pair] = result.checked_without_evidence
    assert "only the Dianben 850 mg comprimidos sheet was searched" in pair


def test_proposed_medicine_without_sheet_is_looked_for_in_the_other_sheets():
    patient = _patient([("63064", "Dr. Gómez (Cardiología)")])
    model = FakeModel()
    result = check_new_medicine(patient, _proposed("07383002"), CATALOGUE, review=model, sheets=WITHOUT_JANUVIA)
    assert model.calls == [("63064", "sitagliptina")]
    assert "only the Aldocumar" in result.checked_without_evidence[0]


def test_pair_with_no_sheet_on_either_side_could_not_be_checked():
    patient = _patient([("63064", "Dr. Gómez")])
    model = FakeModel()
    result = check_new_medicine(patient, _proposed("07383002"), CATALOGUE, review=model, sheets=set())
    assert model.calls == []
    assert any("neither technical sheet" in item for item in result.could_not_check)
    assert result.checked_without_evidence == []


def test_blocked_answers_and_failures_are_never_nothing_found():
    patient = _patient([("63064", "Dr. Gómez (Cardiología)"), ("65461", "Dr. López (Cardiología)")])
    model = FakeModel({
        ("88372", "warfarina"): "rejected",
        ("63064", "ibuprofeno"): "error",
        ("88372", "amlodipino"): RuntimeError("index missing"),
    })
    result = check_new_medicine(patient, _proposed("88372"), CATALOGUE, review=model)
    assert result.checked_without_evidence == []
    blocked, failed = result.could_not_check
    assert blocked.startswith(f"{IBUDOL} + {ALDOCUMAR}:")
    assert "safety check" in blocked and "could not be reached" in blocked
    assert "RuntimeError" in failed and "nothing found in the Amlodipino" in failed
    assert {e["status"] for e in result.log} == {"rejected", "error", "exception", "not_found"}


def test_log_and_findings_line_up_for_the_evaluation():
    """evaluacion/evaluar.py pairs the "found" log entries with the interaction
    findings in order, so they must stay one to one."""
    patient = _patient([("63064", "Dr. Gómez"), ("59718", "Dra. Ruiz"), ("66602", "Dr. Molina")])
    model = FakeModel({("63064", "sertralina"): "found", ("59718", "omeprazol"): "found",
                       ("66602", "warfarina"): "found", ("59718", "warfarina"): "found"})
    result = review_patient(patient, CATALOGUE, use_model=True, review=model)
    found = [e for e in result.log if e["status"] == "found"]
    interactions = [f for f in result.findings if f.tipo == "interaccion"]
    assert len(found) == len(interactions) == 4
    assert [e["sheet"] for e in found] == [f.cita.nregistro for f in interactions]
    assert len(result.interaction_groups) == 3


def test_progress_reaches_the_end():
    seen = []
    patient = _patient([("63064", "Dr. Gómez"), ("65461", "Dr. López")])
    proposed = _proposed("88372")
    check_new_medicine(patient, proposed, CATALOGUE, review=FakeModel(),
                       progress=lambda done, total, label: seen.append((done, total)))
    assert seen[-1] == (4, 4) == (planned_questions(patient, proposed, CATALOGUE),) * 2


# ---------------------------------------------------------------- without rules or model

def test_without_rules_duplicates_use_names_and_the_rest_is_not_checked():
    patient = _patient([("68339", "Dra. Martín (Traumatología)")])  # paracetamol
    model = FakeModel()
    result = check_new_medicine(patient, _proposed("85780"), CATALOGUE, review=model)  # Antidol
    assert model.calls == []
    [finding] = result.findings
    assert finding.tipo == "duplicado" and "paracetamol" in finding.descripcion
    assert result.unchecked == {"advertencia_atc", "cascada"}


def test_without_model_no_question_is_asked_and_interactions_are_not_checked():
    patient = _patient([("63064", "Dr. Gómez")])
    model = FakeModel()
    result = check_new_medicine(patient, _proposed("88372"), CATALOGUE, use_model=False, review=model)
    assert model.calls == []
    assert "interaccion" in result.unchecked


def test_review_asks_about_every_pair():
    patient = _patient([("63064", "Dr. Gómez"), ("65461", "Dr. López"), ("88372", "Dra. Navarro")])
    model = FakeModel({("88372", "warfarina"): "found"})
    result = review_patient(patient, CATALOGUE, use_model=True, review=model)
    assert len(model.calls) == planned_questions(patient, None, CATALOGUE) == 6
    [finding] = [f for f in result.findings if f.tipo == "interaccion"]
    assert "Aldocumar" in finding.pregunta_medico and "Ibudol" in finding.pregunta_medico
    assert len(result.interaction_groups) == 1 and len(result.checked_without_evidence) == 2


# ---------------------------------------------------------------- rules (Person 2)

def _real_rules():
    try:
        from src import reglas
    except SyntaxError as exc:
        pytest.skip(f"src/reglas.py does not load yet ({exc.msg}); fix it to run these tests")
    return reglas


# Codes from Person 2's tests (checked in the nomenclator); ibuprofen and
# furosemide use invented ingredient codes with real ATC codes, as they do.
DRUG_INFO = {
    "68339": {"atc": ["N02BE01"], "active_ingredients": ["350"]},
    "85780": {"atc": ["N02BE01"], "active_ingredients": ["350"]},
    "63064": {"atc": ["B01AA03"], "active_ingredients": ["4411"]},
    "65222": {"atc": ["J01CR02"], "active_ingredients": ["160", "5418"]},
    "65461": {"atc": ["C08CA01"], "active_ingredients": ["7177"]},
    "55211": {"atc": ["A10BA02"], "active_ingredients": ["4379"]},
    "88372": {"atc": ["M01AE01"], "active_ingredients": ["T-IBU"]},
    "64140": {"atc": ["C03CA01"], "active_ingredients": ["T-FUR"]},
}


@pytest.fixture
def rule_data():
    reglas = _real_rules()
    return DRUG_INFO, reglas.load_cascades()


def test_review_with_rules_finds_the_duplicate(rule_data):
    patient = _patient([("68339", "Dra. Martín"), ("85780", "Dr. Ruiz")])
    result = review_patient(patient, CATALOGUE, rule_data=rule_data)
    assert [f.tipo for f in result.findings] == ["duplicado"]
    assert result.unchecked == {"interaccion"}
    question = result.findings[0].pregunta_medico
    assert "Dra. Martín" in question and "Dr. Ruiz" in question and "total daily amount of paracetamol" in question


def test_new_medicine_can_complete_a_cascade(rule_data):
    patient = _patient([("88372", "Dra. Navarro (Traumatología)")])  # ibuprofen
    result = check_new_medicine(patient, _proposed("65461"), CATALOGUE,
                                rule_data=rule_data, use_model=False)  # amlodipine
    [cascade] = [f for f in result.findings if f.tipo == "cascada"]
    assert cascade.descripcion.startswith("C07:")
    assert "The proposed medicine, 'Amlodipino Cinfa 10 mg comprimidos EFG'" in cascade.descripcion
    assert "'Ibudol 400 mg cápsulas blandas', which the patient already takes" in cascade.descripcion
    assert "antihypertensive" in cascade.pregunta_medico.lower()
    assert cascade.pregunta_medico.startswith("Ibudol 400 mg cápsulas blandas and Amlodipino Cinfa")
    assert result.unchecked == {"interaccion"}


def test_new_medicine_check_ignores_findings_between_current_medicines(rule_data):
    patient = _patient([("68339", "Dra. Martín"), ("85780", "Dr. Ruiz")])  # already a duplicate
    result = check_new_medicine(patient, _proposed("63064"), CATALOGUE,
                                rule_data=rule_data, use_model=False)
    assert result.findings == []


def test_rules_run_with_the_medicine_list_codes_when_the_nomenclator_is_missing(tmp_path):
    _real_rules()
    codes = load_rule_data(tmp_path / "missing.json", CATALOGUE)
    duplicate = review_patient(_patient([("68339", "Dra. Martín"), ("85780", "Dr. Ruiz")]),
                               CATALOGUE, rule_data=codes)
    assert [f.tipo for f in duplicate.findings] == ["duplicado"]
    family = review_patient(_patient([("66602", "Dr. Ruiz"), ("74483", "Dr. Molina")]),  # two PPIs
                            CATALOGUE, rule_data=codes)
    assert [f.tipo for f in family.findings] == ["advertencia_atc"]
    assert "A02BC" in family.findings[0].pregunta_medico
    cascade = check_new_medicine(_patient([("88372", "Dra. Navarro")]), _proposed("65461"),
                                 CATALOGUE, rule_data=codes, use_model=False)
    assert [f.tipo for f in cascade.findings] == ["cascada"]


def test_medicine_missing_from_the_nomenclator_is_reported(rule_data):
    patient = _patient([("63064", "Dr. Gómez"), ("07383002", "Dra. Medina")])  # Januvia: no codes
    result = review_patient(patient, CATALOGUE, rule_data=rule_data)
    assert any("Januvia" in item and "nomenclator" in item for item in result.could_not_check)


# ---------------------------------------------------------------- report

def _check_report(patient, proposed, result):
    return generate_report(
        patient, result.findings, checked_without_evidence=result.checked_without_evidence,
        could_not_check=result.could_not_check, proposed=proposed, unchecked_types=result.unchecked,
        interaction_groups=result.interaction_groups, same_ingredient=result.same_ingredient,
    )


def test_check_report_lists_the_proposed_medicine_and_unfinished_checks():
    patient = _patient([("63064", "Dr. Gómez (Cardiología)"), ("65461", "Dr. López")])
    proposed = _proposed("88372")
    model = FakeModel({("88372", "warfarina"): "found", ("88372", "amlodipino"): "rejected",
                       ("65461", "ibuprofeno"): "rejected"})
    result = check_new_medicine(patient, proposed, CATALOGUE, review=model)
    report = _check_report(patient, proposed, result)
    md = report.markdown
    assert "Medicine check before prescribing" in md
    assert "Proposed medicine, not yet prescribed: Dra. Pérez (Atención Primaria)" in md
    assert "## Checks that could not be completed" in md
    assert "Not checked: this part of the system was not available" in md
    assert "Ibudol 400 mg cápsulas blandas (reg. 88372), section 4.5" in md
    assert f"### 4.1 {IBUDOL} + {ALDOCUMAR}" in md
    assert report.counts["interaccion"] == 1 and report.counts["could_not_check"] == 1
    assert report.unchecked == {"advertencia_atc", "cascada"}
    assert report.file_stem.startswith("comprobacion_T_")
    assert report.markdown.rstrip().endswith(f"*{FOOTER}*")


def test_check_report_leaves_out_empty_dose_and_prescriber():
    patient = _patient([("63064", "Dr. Gómez")])
    proposed = Medication(nregistro="88372", nombre=IBUDOL, dosis="Not specified", prescriptor="Not specified")
    result = check_new_medicine(patient, proposed, CATALOGUE, review=FakeModel({("88372", "warfarina"): "found"}))
    md = _check_report(patient, proposed, result).markdown
    assert f"**Proposed medicine:** {IBUDOL}  \n" in md
    assert "Not specified" not in md
    assert "### Proposed medicine, not yet prescribed\n" in md


def test_report_shows_each_pair_once_and_says_why_duplicates_were_not_searched():
    patient = _patient([("55211", "Dra. Medina"), ("76578", "Dr. Ruiz"), ("63064", "Dr. Gómez")])
    model = FakeModel({("55211", "warfarina"): "found", ("63064", "metformina"): "found"})
    result = review_patient(patient, CATALOGUE, use_model=True, review=model)
    report = generate_report(patient, result.findings, checked_without_evidence=result.checked_without_evidence,
                             could_not_check=result.could_not_check, unchecked_types=result.unchecked,
                             interaction_groups=result.interaction_groups, same_ingredient=result.same_ingredient)
    md = report.markdown
    assert report.counts["interaccion"] == 1  # one pair, two quotations
    assert md.count("**Source:**") == 2
    assert "Not searched for interactions with each other" in md
    assert "Pairs checked with no interaction found" not in md
    questions = md.split("## 6. Questions")[1]
    assert questions.count("possible interaction between") == 1


# ---------------------------------------------------------------- status checks

def test_model_status_without_libraries(monkeypatch):
    def missing():
        raise ModuleNotFoundError("No module named 'groq'", name="groq")
    monkeypatch.setattr(revision, "_import_rag", missing)
    ready, message = model_status()
    assert not ready and "groq" in message


def test_model_status_without_index(monkeypatch, tmp_path):
    monkeypatch.setattr(revision, "_import_rag", lambda: None)
    ready, message = model_status(tmp_path / "missing")
    assert not ready and "index" in message


def test_model_status_without_key(monkeypatch, tmp_path):
    monkeypatch.setattr(revision, "_import_rag", lambda: None)
    monkeypatch.delenv("GROQ_API_KEY", raising=False)
    ready, message = model_status(tmp_path)
    assert not ready and "GROQ_API_KEY" in message


def test_model_status_ready(monkeypatch, tmp_path):
    monkeypatch.setattr(revision, "_import_rag", lambda: None)
    monkeypatch.setenv("GROQ_API_KEY", "test-key")
    assert model_status(tmp_path) == (True, "connected")


def test_rules_status_when_the_rules_file_is_broken(monkeypatch):
    def broken():
        raise SyntaxError("from __future__ imports must occur at the beginning of the file")
    monkeypatch.setattr(revision, "_import_rules", broken)
    ready, message = rules_status()
    assert not ready and "could not be loaded" in message


def test_rules_status_without_nomenclator_file_uses_the_medicine_list(monkeypatch, tmp_path):
    monkeypatch.setattr(revision, "_import_rules", lambda: None)
    ready, message = rules_status(tmp_path / "prescriptions.json")
    assert ready and "medicine list" in message


def test_rules_status_with_nomenclator_file(monkeypatch, tmp_path):
    monkeypatch.setattr(revision, "_import_rules", lambda: None)
    path = tmp_path / "prescriptions.json"
    path.write_text("{}", encoding="utf-8")
    assert rules_status(path) == (True, "connected, using the nomenclator codes")


# ---------------------------------------------------------------- stored model answers

def test_all_questions_cover_every_sheet_without_asking_about_its_own_ingredient():
    questions = all_questions(CATALOGUE)
    assert len(questions) == len(set(questions))
    for sheet, ingredient in questions:
        entry = CATALOGUE[sheet]
        assert entry.ficha and ingredient not in entry.principios_activos
    assert ("88372", "warfarina") in questions and ("63064", "ibuprofeno") in questions


def test_stored_answers_are_saved_resumed_and_reused(tmp_path):
    path = tmp_path / "interacciones_guardadas.json"
    questions = [("88372", "warfarina"), ("63064", "ibuprofeno"), ("88372", "amlodipino")]
    model = FakeModel({("88372", "warfarina"): "found", ("88372", "amlodipino"): "error"})
    counts = save_answers(path, model, questions, log=lambda _: None)
    assert counts == {"asked": 3, "skipped": 0, "kept": 2, "retry_later": 1}

    # A second run asks only the question that failed.
    model2 = FakeModel()
    counts = save_answers(path, model2, questions, log=lambda _: None)
    assert model2.calls == [("88372", "amlodipino")] and counts["kept"] == 1

    stored = load_stored_answers(path)
    assert stored.sheets == {"88372", "63064"}
    patient = _patient([("63064", "Dr. Gómez (Cardiología)"), ("65461", "Dr. López"), ("64140", "Dr. Ruiz")])
    result = check_new_medicine(patient, _proposed("88372"), CATALOGUE, review=stored_review(stored))
    [finding] = [f for f in result.findings if f.tipo == "interaccion"]
    assert finding.cita.nregistro == "88372"
    # amlodipine's and furosemide's sheets have no stored answers: one note per sheet
    assert any("Amlodipino" in item and "not available in this version" in item
               for item in result.could_not_check)
    # a stored sheet with one search missing: reported, never "nothing found"
    assert any("Furosemida" in item and "not in the stored model answers" in item
               for item in result.could_not_check)


def test_no_stored_file_means_none(tmp_path):
    assert load_stored_answers(tmp_path / "missing.json") is None


def test_storing_script_stops_without_the_model(monkeypatch, capsys):
    from src import guardar_interacciones

    monkeypatch.setattr(guardar_interacciones, "model_status", lambda: (False, "no key"))
    assert guardar_interacciones.main([]) == 1
    assert "no key" in capsys.readouterr().out


def test_storing_script_skips_sheets_that_are_not_in_the_cima_file(monkeypatch, capsys, tmp_path):
    from src import guardar_interacciones

    asked = []
    monkeypatch.setattr(guardar_interacciones, "model_status", lambda: (True, "connected"))
    monkeypatch.setattr(guardar_interacciones, "_review_interaction", lambda: "review")
    monkeypatch.setattr(guardar_interacciones, "index_sheets", lambda: WITHOUT_JANUVIA)
    monkeypatch.setattr(guardar_interacciones, "STORED_ANSWERS_FILE", tmp_path / "answers.json")
    monkeypatch.setattr(guardar_interacciones, "save_answers",
                        lambda path, review, questions, pause: asked.extend(questions)
                        or {"kept": 0, "skipped": 0, "retry_later": 0})
    assert guardar_interacciones.main([]) == 0
    out = capsys.readouterr().out
    assert "07383002  Januvia" in out and "python3 src/parse_cima.py" in out and "07383002" in out.split("parse_cima.py")[1]
    assert asked and not any(sheet == "07383002" for sheet, _ in asked)



# ---------------------------------------------------------------- typed questions and live steps

from src.revision import answer_typed_question, classify_answer, find_medicines, live_review_with_steps


@pytest.mark.parametrize("question, expected", [
    ("¿Puedo añadirle Aldocumar?", ["63064"]),
    ("Can I add omeprazole?", ["66602"]),
    ("Quiero recetar Atorvastatina Stada 80 mg", ["80733"]),            # the product, not every atorvastatin
    ("¿Le doy atorvastatina?", ["69534", "80733"]),                       # an ingredient: every product
    ("¿ibuprofeno con warfarina?", ["88372", "66327", "63064"]),          # in the order they appear
    ("algo para el dolor", []),
])
def test_find_medicines_in_a_typed_question(question, expected):
    assert [r.entry.nregistro for r in find_medicines(question, CATALOGUE)] == expected


def test_find_medicines_says_which_ones_the_patient_already_takes():
    patient = _patient([("63064", "Dr. Gómez")])
    found = {r.entry.nregistro: r.already_taken for r in find_medicines("warfarin and ibuprofen?", CATALOGUE, patient)}
    assert found == {"63064": True, "88372": False, "66327": False}


def _fake_rag(answers: dict):
    """A stand-in for src.rag with the same functions the screen uses."""
    import types

    rag = types.ModuleType("fake_rag")

    class Response:
        def __init__(self, data):
            self.data = data

        def model_dump(self):
            return self.data

    def fragment(n, i, text):
        return {"id": f"{n}_{i}", "nregistro": n, "nombre": CATALOGUE[n].nombre, "seccion": "4.5",
                "titulo": "Interacción", "texto": text, "distance": 0.2 + i / 10}

    def search_fragments(question, nregistro=None, sections=None, k=3):
        return [fragment(nregistro, 0, "Los AINE pueden aumentar los efectos de la warfarina."),
                fragment(nregistro, 1, "Alimentos y alcohol.")]

    def prepare_interaction_search(n, ingredient, k=3):
        q = f"¿Qué posible interacción se describe con {ingredient}?"
        kept = [f for f in search_fragments(q, n) if ingredient in f["texto"]]
        return {"status": "ready" if kept else "not_found", "question": q, "fragments": kept, "messages": [],
                "key": (n, ingredient)}

    def prepare_general_search(question, nregistro=None, sections=None, k=3):
        return {"status": "ready", "question": question, "fragments": search_fragments(question, nregistro),
                "messages": [], "key": (nregistro, "question")}

    def llm_medication_review(messages):
        return Response(rag.pending)

    def run_prepared_request(prepared):
        if not prepared["fragments"]:
            return {"status": "not_found", "reason": "no_evidence", "fragments": [], "response": None}
        rag.pending = answers[prepared["key"]]["raw"]
        rag.llm_medication_review(prepared["messages"])
        return {k: v for k, v in answers[prepared["key"]].items() if k != "raw"}

    rag.__dict__.update(search_fragments=search_fragments, prepare_interaction_search=prepare_interaction_search,
                        prepare_general_search=prepare_general_search, run_prepared_request=run_prepared_request,
                        llm_medication_review=llm_medication_review)
    return rag


FOUND = {"status": "found", "description": "El ibuprofeno puede aumentar los efectos de la warfarina.",
         "citations": [{"nregistro": "88372", "seccion": "4.5",
                        "literal_quote": "Los AINE pueden aumentar los efectos de la warfarina."}]}
INVENTED = {"status": "found", "description": "Puede aumentar el efecto.",
            "citations": [{"nregistro": "88372", "seccion": "4.5", "literal_quote": "texto que no está en la ficha"}]}


def test_live_steps_show_search_keep_model_and_checks(monkeypatch):
    rag = _fake_rag({("88372", "warfarina"): {"status": "found", "reason": None, "response": FOUND, "raw": FOUND}})
    monkeypatch.setattr(revision, "_import_rag", lambda: rag)
    seen = []
    patient = _patient([("63064", "Dr. Gómez")])
    result = check_new_medicine(patient, _proposed("88372"), CATALOGUE,
                                review=live_review_with_steps(lambda stage, data: seen.append((stage, data))),
                                steps=lambda stage, data: seen.append((stage, data)))
    stages = [stage for stage, _ in seen]
    # Ibudol's sheet: search, keep 1 of 2, ask the model, answer. Aldocumar's: no passage mentions
    # ibuprofen, so the model is not asked.
    assert stages == ["retrieved", "asking", "answered", "retrieved", "answered"]
    retrieved = seen[0][1]
    assert len(retrieved["retrieved"]) == 2 and len(retrieved["kept_ids"]) == 1
    assert seen[2][1]["outcome"] == "found" and seen[2][1]["answer"]["model_answer"] == FOUND
    assert seen[4][1]["outcome"] == "not_found"
    [group] = result.interaction_groups
    assert group.findings[0].cita.literal_quote == FOUND["citations"][0]["literal_quote"]


def test_live_steps_keep_the_rejected_answer_to_show_it(monkeypatch):
    rag = _fake_rag({("88372", "warfarina"): {"status": "rejected", "reason": "invalid_citation",
                                              "response": None, "raw": INVENTED}})
    monkeypatch.setattr(revision, "_import_rag", lambda: rag)
    answers = []
    review = live_review_with_steps(lambda stage, data: None)
    answers.append(review("88372", "warfarina"))
    assert answers[0]["status"] == "rejected"
    assert answers[0]["model_answer"] == INVENTED  # shown on screen as what the model said
    assert classify_answer(answers[0])[0] == "failed"


def test_typed_question_is_answered_from_the_medicine_sheet(monkeypatch):
    rag = _fake_rag({("88372", "question"): {"status": "found", "reason": None, "response": FOUND, "raw": FOUND}})
    monkeypatch.setattr(revision, "_import_rag", lambda: rag)
    seen = []
    answer = answer_typed_question("¿Puedo añadirle ibuprofeno?", "88372", steps=lambda s, d: seen.append(s))
    assert answer["status"] == "found" and seen == ["retrieved", "asking"]

    patient = _patient([("63064", "Dr. Gómez")])
    proposed = _proposed("88372")
    result = check_new_medicine(patient, proposed, CATALOGUE, review=FakeModel())
    md = generate_report(patient, result.findings, proposed=proposed, question="¿Puedo añadirle ibuprofeno?",
                         question_answer={"status": "found", "response": FOUND}).markdown
    assert "## Your question" in md and "**Question:** ¿Puedo añadirle ibuprofeno?" in md
    assert "section 4.5" in md.split("## Summary")[0]
    assert md.index("## Your question") < md.index("## Summary")


def test_typed_question_answer_with_forbidden_wording_is_withheld():
    patient = _patient([("63064", "Dr. Gómez")])
    proposed = _proposed("88372")
    unsafe = {**FOUND, "description": "Deje de tomar la warfarina antes de empezar."}
    report = generate_report(patient, [], proposed=proposed, question="¿Ibuprofeno?",
                             question_answer={"status": "found", "response": unsafe})
    assert report.safety_flags and "Deje de tomar" not in report.markdown


def test_typed_question_carries_the_patient_context():
    from src.revision import question_with_context

    patient = _patient([("63064", "Dr. Gómez"), ("65222", "Dra. Ruiz")])
    text = question_with_context("¿Puedo añadirle ibuprofeno?", patient, CATALOGUE)
    assert text.startswith("¿Puedo añadirle ibuprofeno? (Contexto: paciente de")
    assert "warfarina, amoxicilina y ácido clavulánico" in text


@pytest.mark.parametrize("question, about_medicines", [
    ("¿Hay interacciones?", True),
    ("Any interactions between her medicines?", True),
    ("¿Qué enfermedad tiene este paciente?", False),   # the tool does not diagnose
    ("¿Cuál es la capital de Francia?", False),        # outside what the tool does
])
def test_questions_without_a_medicine_name(question, about_medicines):
    from src.revision import asks_about_medicines

    assert find_medicines(question, CATALOGUE) == []
    assert asks_about_medicines(question) is about_medicines


def test_report_can_say_what_it_covers():
    patient = _patient([("63064", "Dr. Gómez")])
    md = generate_report(patient, [], question="¿Debería dejar de tomar Aldocumar?",
                         question_answer={"status": "note", "detail": "Only this medicine was checked."},
                         scope_note="Your question is about Aldocumar.").markdown
    assert "_Your question is about Aldocumar._" in md and "_Only this medicine was checked._" in md
