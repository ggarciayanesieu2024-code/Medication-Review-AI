"""Ask the model every interaction question once and store the answers (Person 5).

Run on a computer where the model is set up (full requirements.txt, the search
index built from the shared CIMA file, GROQ_API_KEY in .env), from the project
root:

    python -m src.guardar_interacciones

It writes data/interacciones_guardadas.json with one answer per (technical
sheet, ingredient) search for the medicines in data/catalogo_medicamentos.json.
Upload that file to GitHub: the shared link, and any computer without the
model, then shows these stored answers instead of "Not checked".

The answers are saved after each question. Running the command again only asks
the questions that are missing, so it can be repeated after an interruption or
an API limit, or after new medicines or sheets are added. Use --start-over only
when the text of sheets already stored has changed.

Sheets that are not in the CIMA file (data/processed/fragmentos_cima.json) are
skipped and listed: searching them would only ever give "nothing found", which
would be stored as if the sheet had been read. The script prints the
src/parse_cima.py command that adds them.
"""
from __future__ import annotations

import argparse

from src.revision import (
    STORED_ANSWERS_FILE,
    all_questions,
    index_sheets,
    load_catalogue,
    model_status,
    save_answers,
)


def _review_interaction():
    from src.rag import review_interaction  # needs the full requirements.txt

    return review_interaction


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    parser.add_argument(
        "--pause", type=float, default=2.0,
        help="seconds to wait after each question that reached the model (default 2, "
             "to stay under Groq's free-tier limit)",
    )
    parser.add_argument(
        "--start-over", action="store_true",
        help="delete the stored answers first (after the CIMA file or the medicine list changes)",
    )
    args = parser.parse_args(argv)

    ready, message = model_status()
    if not ready:
        print(f"The model is not available on this computer: {message}")
        return 1
    review_interaction = _review_interaction()

    catalogue = load_catalogue()
    in_file = index_sheets()
    if in_file is None:
        print("The CIMA file data/processed/fragmentos_cima.json is missing or unreadable.")
        return 1
    questions = all_questions(catalogue)
    missing = sorted({sheet for sheet, _ in questions} - in_file)
    if missing:
        print("These technical sheets are not in the CIMA file, so they are skipped:")
        for nregistro in missing:
            print(f"  {nregistro}  {catalogue[nregistro].nombre}")
        numbers = " ".join(sorted(in_file | set(missing)))
        print("To add them, run these two commands, then this one again:\n"
              f"  python3 src/parse_cima.py {numbers}\n"
              "  python3 -m src.indice\n")
        questions = [q for q in questions if q[0] in in_file]

    if args.start_over and STORED_ANSWERS_FILE.exists():
        STORED_ANSWERS_FILE.unlink()

    print(f"{len(questions)} searches to store in {STORED_ANSWERS_FILE}.")
    counts = save_answers(STORED_ANSWERS_FILE, review_interaction, questions, pause=args.pause)
    print(
        f"\nDone: {counts['kept']} new answers stored, {counts['skipped']} already stored, "
        f"{counts['retry_later']} to retry."
    )
    if counts["retry_later"]:
        print("Run the same command again in a few minutes to retry those.")
    else:
        print("Upload data/interacciones_guardadas.json to GitHub.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
