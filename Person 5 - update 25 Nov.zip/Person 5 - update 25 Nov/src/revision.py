"""Run the real checks for the screen (Person 5).

Two entry points, one per tab:

* ``review_patient``: checks every medicine a patient already takes.
* ``check_new_medicine``: checks a proposed medicine against the patient's
  current medicines, before it is prescribed.

Both use whatever parts of the system are available, and say which parts were
not checked, so the report never shows "None found" for something nobody looked
at:

1. **Rules (Person 2, ``src/reglas.py``):** duplicates (shared active-ingredient
   code), same drug family (ATC) and prescribing cascades. They need
   ``data/processed/prescriptions.json`` for the nomenclator codes. Without it
   (for example on the shared link) they use the ATC codes and ingredient
   names in ``data/catalogo_medicamentos.json``. If ``src/reglas.py`` cannot be
   loaded, duplicates fall back to a name comparison and drug families and
   cascades are marked "not checked".
2. **Model (Person 3, ``src.rag.review_interaction``):** for each pair of
   medicines, each technical sheet is searched for the other medicine's active
   ingredient (both directions). It needs the search index and GROQ_API_KEY.
   Without them, the screen uses **stored answers** when
   ``data/interacciones_guardadas.json`` exists: the same questions, asked once
   on a computer with the model by ``python -m src.guardar_interacciones``.
   With neither, interactions are marked "not checked".

Medicines with the same active ingredients are searched together, so the same
(sheet, ingredient) search is never asked twice, and they are not searched for
interactions with each other (they are a duplicate; the report says so).

Each model answer becomes one of four things:

* ``found``: a Finding with the verified quotation from the technical sheet.
* ``found`` but the text only says the sheet describes NO interaction (for
  example "amlodipino no afecta la farmacocinética de la atorvastatina"):
  counted as "no interaction found", never as an interaction.
* ``not_found``: "searched, nothing found".
* ``rejected`` / ``error`` / an exception: "could not be checked". Never shown
  as "nothing found"; the pair needs manual review.

The report then gives ONE result per pair of medicines, whichever direction
gave it: an interaction if either sheet describes one; otherwise "could not be
checked" if a search failed; otherwise "no interaction found" (which does not
mean the combination is safe). The counts on screen are counts of pairs.

The system informs; the prescriber decides. Nothing here says whether a
medicine can or cannot be prescribed.
"""
from __future__ import annotations

import json
import os
import re
import time
from contextvars import ContextVar
from dataclasses import dataclass, field
from datetime import date
from itertools import combinations
from pathlib import Path
from typing import Callable

from src.config import DATA_DIR, DATABASE_DIR, FRAGMENTS_FILE, PRESCRIPTIONS_FILE
from src.informe import InteractionGroup, normalise_text
from src.modelos import Citation, Finding, Medication, Patient

CATALOGUE_FILE = DATA_DIR / "catalogo_medicamentos.json"
STORED_ANSWERS_FILE = DATA_DIR / "interacciones_guardadas.json"

REASON_TEXT = {
    "forbidden_phrase": "the model's answer was blocked by the safety check",
    "invalid_citation": "the model's answer quoted text that could not be verified",
    "invalid_response": "the model's answer was not in the expected format",
    "generation_failed": "the model could not be reached",
    "not_stored": "this search is not in the stored model answers",
}

# What the screen puts in an empty dose or prescriber field.
NOT_SPECIFIED = "Not specified"

Progress = Callable[[int, int, str], None]
# Called with ("retrieved" | "asking" | "answered", details) so the screen can
# show each step of a search as it happens.
Steps = Callable[[str, dict], None]


@dataclass
class CatalogueEntry:
    nregistro: str
    nombre: str
    principios_activos: list[str]
    ficha: bool
    atc: list[str] = field(default_factory=list)


@dataclass
class CheckResult:
    findings: list[Finding] = field(default_factory=list)
    # One line per pair of medicines searched with no interaction found.
    checked_without_evidence: list[str] = field(default_factory=list)
    # One line per pair (or medicine, or missing sheet) that could not be checked.
    could_not_check: list[str] = field(default_factory=list)
    # The interaction findings grouped by pair of medicines, for the report.
    interaction_groups: list[InteractionGroup] = field(default_factory=list)
    # Pairs not searched for interactions because they share an ingredient.
    same_ingredient: list[str] = field(default_factory=list)
    # Finding types that were not looked for at all (shown as "Not checked").
    unchecked: set[str] = field(default_factory=set)
    # One entry per model question, for the evaluation (deliverable 5).
    log: list[dict] = field(default_factory=list)


# --------------------------------------------------------------------------
# Data and availability
# --------------------------------------------------------------------------

def load_catalogue(path: str | Path = CATALOGUE_FILE) -> dict[str, CatalogueEntry]:
    """Read the medicine list, keyed by registration number."""
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    return {
        item["nregistro"]: CatalogueEntry(
            nregistro=item["nregistro"],
            nombre=item["nombre"],
            principios_activos=list(item["principios_activos"]),
            ficha=bool(item["ficha"]),
            atc=list(item.get("atc", [])),
        )
        for item in data["medicamentos"]
    }


def _import_rag():
    from src import rag  # needs groq, chromadb and sentence-transformers

    return rag


def _import_rules():
    from src import reglas

    return reglas


def model_status(database_dir: Path = DATABASE_DIR) -> tuple[bool, str]:
    """Return (ready, explanation) for the model, without calling it."""
    try:
        _import_rag()
    except ImportError as exc:
        return False, (
            f"the model's libraries are not installed here ({exc.name}). "
            "Install the full requirements.txt."
        )
    if not Path(database_dir).exists():
        return False, (
            "the search index is missing. Put the shared CIMA file in data/processed/ "
            "and run src/indice.py."
        )
    key = os.getenv("GROQ_API_KEY")
    if not key or key == "your_groq_api_key_here":
        return False, "GROQ_API_KEY is missing from the .env file."
    return True, "connected"


def cloud_only_files(*folders: str | Path) -> list[Path]:
    """Files in ``folders`` that are only in iCloud, not on this Mac.

    A project on the Desktop or in Documents synced with iCloud can lose its
    local copy of large files (the search model, the index). The model then
    waits for them to download, and the screen looks frozen. Only macOS marks
    these files (SF_DATALESS); elsewhere this returns an empty list."""
    import stat

    flag = getattr(stat, "SF_DATALESS", 0x40000000)
    found = []
    for folder in folders:
        folder = Path(folder)
        if not folder.exists():
            continue
        for path in folder.rglob("*"):
            try:
                info = path.stat()
            except OSError:
                continue
            if path.is_file() and getattr(info, "st_flags", 0) & flag:
                found.append(path)
    return found


def rules_status(prescriptions_file: Path = PRESCRIPTIONS_FILE) -> tuple[bool, str]:
    """Return (ready, explanation) for Person 2's rules."""
    try:
        _import_rules()
    except Exception as exc:  # a SyntaxError or ImportError inside src/reglas.py
        return False, f"src/reglas.py could not be loaded ({type(exc).__name__}: {exc})."
    if not Path(prescriptions_file).exists():
        return True, (
            "connected, using the ATC codes in the medicine list "
            "(data/processed/prescriptions.json was not found)"
        )
    return True, "connected, using the nomenclator codes"


def load_rule_data(
    prescriptions_file: Path = PRESCRIPTIONS_FILE,
    catalogue: dict[str, CatalogueEntry] | None = None,
) -> tuple[dict, dict]:
    """(drug codes per registration number, cascade table) for the rules.

    Uses the nomenclator file when it exists. Otherwise builds the codes from the
    medicine list: its ATC codes, and its ingredient names in place of the
    nomenclator ingredient codes (the rules only compare them for equality).
    """
    reglas = _import_rules()
    if Path(prescriptions_file).exists():
        drug_info = reglas.load_drug_info(Path(prescriptions_file))
    else:
        catalogue = catalogue if catalogue is not None else load_catalogue()
        drug_info = {
            n: {"atc": list(e.atc),
                "active_ingredients": [f"name:{normalise_text(i)}" for i in e.principios_activos]}
            for n, e in catalogue.items() if e.atc
        }
    return drug_info, reglas.load_cascades()


# --------------------------------------------------------------------------
# Stored model answers (for computers without the model, such as the shared link)
# --------------------------------------------------------------------------

@dataclass
class StoredAnswers:
    generated_at: str
    answers: dict[tuple[str, str], dict]

    @property
    def sheets(self) -> set[str]:
        """The technical sheets that have stored answers."""
        return {sheet for sheet, _ in self.answers}


def load_stored_answers(path: str | Path = STORED_ANSWERS_FILE) -> StoredAnswers | None:
    """Read data/interacciones_guardadas.json, or None if it does not exist."""
    path = Path(path)
    if not path.exists():
        return None
    data = json.loads(path.read_text(encoding="utf-8"))
    return StoredAnswers(
        generated_at=data.get("generated_at", "an unknown date"),
        answers={(a["sheet"], normalise_text(a["ingredient"])): a for a in data.get("answers", [])},
    )


def stored_review(stored: StoredAnswers) -> Callable[[str, str], dict]:
    """A stand-in for review_interaction that answers from the stored file."""
    def review(nregistro: str, ingredient: str) -> dict:
        answer = stored.answers.get((nregistro, normalise_text(ingredient)))
        if answer is None:
            return {"status": "error", "reason": "not_stored", "response": None}
        return {"status": answer["status"], "reason": answer.get("reason"),
                "response": answer.get("response")}
    # Sheets with no stored answers are treated as "not available in this
    # version" (one note per sheet) rather than one failure per search.
    review.sheets = stored.sheets
    return review


def all_questions(catalogue: dict[str, CatalogueEntry]) -> list[tuple[str, str]]:
    """Every (sheet, ingredient) search any patient or new medicine can need."""
    ingredients: dict[str, str] = {}
    for entry in catalogue.values():
        for ingredient in entry.principios_activos:
            ingredients.setdefault(normalise_text(ingredient), ingredient)
    questions = []
    for entry in sorted(catalogue.values(), key=lambda e: e.nregistro):
        if not entry.ficha:
            continue
        own = {normalise_text(i) for i in entry.principios_activos}
        questions += [(entry.nregistro, name) for key, name in sorted(ingredients.items()) if key not in own]
    return questions


def save_answers(
    path: str | Path,
    review: Callable[[str, str], dict],
    questions: list[tuple[str, str]],
    *,
    pause: float = 0.0,
    log: Callable[[str], None] = print,
) -> dict[str, int]:
    """Ask the questions not stored yet and save the answers after each one.

    Found, not found and rejected answers are kept. Errors (for example the API
    limit) are left out, so running the script again retries only those.
    """
    path = Path(path)
    data = json.loads(path.read_text(encoding="utf-8")) if path.exists() else {"answers": []}
    stored = {(a["sheet"], normalise_text(a["ingredient"])) for a in data["answers"]}
    counts = {"asked": 0, "skipped": 0, "kept": 0, "retry_later": 0}
    total = len(questions)
    for number, (sheet, ingredient) in enumerate(questions, start=1):
        if (sheet, normalise_text(ingredient)) in stored:
            counts["skipped"] += 1
            continue
        counts["asked"] += 1
        try:
            answer = review(sheet, ingredient)
        except Exception as exc:
            counts["retry_later"] += 1
            log(f"[{number}/{total}] {sheet} / {ingredient}: failed ({type(exc).__name__}); run again later")
            continue
        status = answer.get("status")
        if status not in ("found", "not_found", "rejected"):
            counts["retry_later"] += 1
            log(f"[{number}/{total}] {sheet} / {ingredient}: {status} ({answer.get('reason')}); run again later")
            continue
        data["answers"].append({
            "sheet": sheet,
            "ingredient": ingredient,
            "status": status,
            "reason": answer.get("reason"),
            "response": answer.get("response"),
            "sources": [{"nregistro": f.get("nregistro"), "seccion": f.get("seccion")}
                        for f in answer.get("fragments") or [] if isinstance(f, dict)],
        })
        counts["kept"] += 1
        data["generated_at"] = date.today().isoformat()
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(data, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
        log(f"[{number}/{total}] {sheet} / {ingredient}: {status}")
        if pause and answer.get("fragments"):  # only searches that reached the model count
            time.sleep(pause)
    return counts


# --------------------------------------------------------------------------
# Rules
# --------------------------------------------------------------------------

def _join(items: list[str], conjunction: str = "and") -> str:
    items = list(dict.fromkeys(i for i in items if i))
    if len(items) <= 1:
        return "".join(items)
    return ", ".join(items[:-1]) + f" {conjunction} " + items[-1]


def _named(name: str, prescriber: str) -> str:
    """'Antidol 1 g (Dr. Ruiz)', or just the name when the prescriber is unknown."""
    return f"{name} ({prescriber})" if prescriber and prescriber != NOT_SPECIFIED else name


def _shared_ingredients(a: str, b: str, catalogue: dict[str, CatalogueEntry] | None) -> str:
    """The active ingredient(s) two medicines share, by name, for the questions."""
    ea, eb = (catalogue or {}).get(a), (catalogue or {}).get(b)
    if ea is None or eb is None:
        return "the shared active ingredient"
    names_b = {normalise_text(i) for i in eb.principios_activos}
    return _join([i for i in ea.principios_activos if normalise_text(i) in names_b]) or "the shared active ingredient"


def _rule_findings(
    medications: list[Medication], rule_data: tuple[dict, dict], proposed: int | None, result: CheckResult,
    catalogue: dict[str, CatalogueEntry] | None = None,
) -> None:
    """Run Person 2's rules. With ``proposed`` (an index into ``medications``),
    keep only the findings that involve that medicine."""
    reglas = _import_rules()
    drug_info, cascade_table = rule_data
    rule_meds, keep = [], None
    for i, med in enumerate(medications):
        info = drug_info.get(med.nregistro)
        if info is None:
            result.could_not_check.append(
                f"{med.nombre}: not found in the nomenclator data, so it was left out of the "
                "duplicate, drug-family and cascade checks."
            )
            continue
        rule_med = reglas.Medication(
            nregistro=med.nregistro, name=med.nombre, prescriber=med.prescriptor,
            atc=list(info["atc"]), active_ingredients=list(info["active_ingredients"]),
        )
        rule_meds.append(rule_med)
        if i == proposed:
            keep = rule_med
    if proposed is not None and keep is None:
        return  # the proposed medicine has no codes; already noted above

    def involved(*meds) -> bool:
        return keep is None or any(m is keep for m in meds)

    def other(a, b):
        return b if a is keep else a

    for d in reglas.find_duplicates(rule_meds):
        a, b = d.medication_a, d.medication_b
        if not involved(a, b):
            continue
        shared = _shared_ingredients(a.nregistro, b.nregistro, catalogue)
        if keep:
            o = other(a, b)
            question = (f"The patient already takes {_named(o.name, o.prescriber)}, which also contains "
                        f"{shared}. What total daily amount of {shared} would the patient take with both?")
        else:
            question = (f"{_named(a.name, a.prescriber)} and {_named(b.name, b.prescriber)} both contain "
                        f"{shared}. Is the patient taking both, and what total daily amount of {shared} "
                        "does that add up to?")
        result.findings.append(Finding(tipo="duplicado", descripcion=d.message, pregunta_medico=question))

    for w in reglas.find_family_warnings(rule_meds):
        a, b = w.medication_a, w.medication_b
        if not involved(a, b):
            continue
        if keep:
            o = other(a, b)
            question = (f"The patient already takes {_named(o.name, o.prescriber)}, from the same drug family "
                        f"(ATC {w.atc_family}) as {keep.name}. Is taking both intended?")
        else:
            question = (f"{_named(a.name, a.prescriber)} and {_named(b.name, b.prescriber)} belong to the same "
                        f"drug family (ATC {w.atc_family}). Is taking both intended, and is each prescriber "
                        "aware of the other?")
        result.findings.append(Finding(tipo="advertencia_atc", descripcion=w.message, pregunta_medico=question))

    for c in reglas.find_cascades(rule_meds, cascade_table):
        if not involved(c.index_medication, c.cascade_medication):
            continue
        effect = c.adverse_effect[:1].lower() + c.adverse_effect[1:]
        if keep is c.cascade_medication:  # the proposed medicine would complete the cascade
            text = (f"{c.cascade_id}: '{c.index_medication.name}', which the patient already takes, can "
                    f"cause {effect}. The proposed medicine, '{keep.name}', is the kind of medicine "
                    "often added to treat it. Possible prescribing cascade to review.")
        elif keep is c.index_medication:
            text = (f"{c.cascade_id}: the proposed medicine, '{keep.name}', can cause {effect}, and the "
                    f"patient already takes '{c.cascade_medication.name}', which is often used to treat "
                    "it. Possible prescribing cascade to review.")
        else:
            text = f"{c.cascade_id}: {c.message}"
        if c.note:
            text += f" {c.note}"
        if c.sources:
            text += f" Sources: {'; '.join(c.sources)}"
        question = f"{c.index_medication.name} and {c.cascade_medication.name}: {c.question}"
        result.findings.append(Finding(tipo="cascada", descripcion=text, pregunta_medico=question))


def _name_duplicates(
    pairs: list[tuple[Medication, Medication]], catalogue: dict[str, CatalogueEntry],
    proposed: Medication | None, result: CheckResult,
) -> None:
    """Fallback when the rules are not available: compare ingredient names."""
    for x, y in pairs:
        ex, ey = catalogue.get(x.nregistro), catalogue.get(y.nregistro)
        if ex is None or ey is None:
            continue
        names_y = {normalise_text(i) for i in ey.principios_activos}
        shared = [i for i in ex.principios_activos if normalise_text(i) in names_y]
        if not shared:
            continue
        ingredient = _join(shared)
        if proposed is not None:
            result.findings.append(Finding(
                tipo="duplicado",
                descripcion=(
                    f"The proposed medicine ({x.nombre}) and {y.nombre}, prescribed by "
                    f"{y.prescriptor}, contain the same active ingredient: {ingredient}."
                ),
                pregunta_medico=(
                    f"The patient already takes {_named(y.nombre, y.prescriptor)}, which also contains "
                    f"{ingredient}. What total daily amount of {ingredient} would the patient take with both?"
                ),
            ))
        else:
            result.findings.append(Finding(
                tipo="duplicado",
                descripcion=(
                    f"{x.nombre} ({x.prescriptor}) and {y.nombre} ({y.prescriptor}) contain "
                    f"the same active ingredient: {ingredient}."
                ),
                pregunta_medico=(
                    f"{_named(x.nombre, x.prescriptor)} and {_named(y.nombre, y.prescriptor)} both contain "
                    f"{ingredient}. Is the patient taking both, and what total daily amount of {ingredient} "
                    "does that add up to?"
                ),
            ))




# --------------------------------------------------------------------------
# Model
# --------------------------------------------------------------------------

# Wording that means "the sheet mentions the medicine but describes no effect".
# Checked on accent-free lower-case text. Only clear cases count: if the
# description also has any sign of an effect (see _EFFECT_WORDING), it stays an
# interaction, because hiding a real interaction is the worse mistake.
_NO_EFFECT_WORDING = [
    r"\bno afect",
    r"\bno (modifica|modifico|altera|altero)\b",
    r"\bno se (describe|describen|ha descrito|han descrito|observ|ha observado|han observado)\b",
    r"\bno (hay|existe|presenta|tiene) (ninguna )?interacci",
    r"\bno interact",
    r"\bno interacciona",
    r"\bninguna interaccion",
    r"\bsin (interaccion|efecto|cambios)",
    r"\b(did|does) not affect\b",
    r"\bno (clinically )?(relevant |significant )?(interaction|effect)\b",
]
_EFFECT_WORDING = [
    r"\bno se (puede )?(descart|exclu)",
    r"\bno puede(n)? (descartarse|excluirse)",
    r"\bpuede", r"\bpodria", r"aument", r"reduc", r"disminu", r"increment", r"potenci",
    r"riesgo", r"monitoriz", r"precaucion", r"vigil", r"control",
    r"\bmay\b", r"\bcan\b", r"increase", r"decrease", r"risk", r"monitor",
]


def describes_no_interaction(description: str | None) -> bool:
    """True when a 'found' answer only says the sheet describes NO interaction,
    for example "amlodipino no afecta la farmacocinética de la atorvastatina"."""
    text = normalise_text(description or "")
    if not any(re.search(p, text) for p in _NO_EFFECT_WORDING):
        return False
    return not any(re.search(p, text) for p in _EFFECT_WORDING)


def index_sheets(path: str | Path = FRAGMENTS_FILE) -> set[str] | None:
    """Registration numbers of the sheets in the CIMA file the search index is
    built from, or None if that file is not on this computer."""
    path = Path(path)
    if not path.exists():
        return None
    try:
        return {f["nregistro"] for f in json.loads(path.read_text(encoding="utf-8"))}
    except (OSError, ValueError, KeyError, TypeError):
        return None


@dataclass
class _Unit:
    """One or more of the patient's medicines with the same active ingredients.

    Medicines with the same ingredients (a duplicate, such as two metformin
    brands) are searched together, so the same search is never asked twice."""
    meds: list[Medication]
    entries: list[CatalogueEntry]

    @property
    def keys(self) -> frozenset[str]:
        return frozenset(normalise_text(i) for i in self.entries[0].principios_activos)

    @property
    def ingredients(self) -> list[str]:
        return list(self.entries[0].principios_activos)

    @property
    def label(self) -> str:
        return " / ".join(dict.fromkeys(m.nombre for m in self.meds))


@dataclass
class _Search:
    sheet: CatalogueEntry
    ingredient: str
    outcome: str = ""  # found, no_interaction, not_found or failed
    detail: str = ""
    answer: dict | None = None
    section: str = ""


@dataclass
class _Pair:
    a: _Unit
    b: _Unit
    searches: list[tuple[str, str]] = field(default_factory=list)
    missing: list[str] = field(default_factory=list)  # medicines whose sheet is not available

    @property
    def label(self) -> str:
        return f"{self.a.label} + {self.b.label}"

    @property
    def prescribers(self) -> list[str]:
        return [m.prescriptor for m in self.a.meds + self.b.meds if m.prescriptor != NOT_SPECIFIED]


def _has_sheet(entry: CatalogueEntry, sheets: set[str] | None) -> bool:
    return entry.ficha and (sheets is None or entry.nregistro in sheets)


def _units(medications: list[Medication], catalogue: dict[str, CatalogueEntry], result: CheckResult) -> list[_Unit]:
    units: dict[frozenset[str], _Unit] = {}
    for med in medications:
        entry = catalogue.get(med.nregistro)
        if entry is None:
            note = f"{med.nombre}: not in the medicine list, so its active ingredient is unknown and it was not searched for interactions."
            if note not in result.could_not_check:
                result.could_not_check.append(note)
            continue
        key = frozenset(normalise_text(i) for i in entry.principios_activos)
        if key in units:
            units[key].meds.append(med)
            units[key].entries.append(entry)
        else:
            units[key] = _Unit([med], [entry])
    return list(units.values())


def _same_ingredient(meds: list[Medication], shared: list[str]) -> str:
    names = " + ".join(dict.fromkeys(m.nombre for m in meds))
    return (f"{names}: they contain the same active ingredient ({_join(shared)}), so they were not "
            "searched for interactions with each other (see Duplicates).")


def _plan(
    medications: list[Medication], catalogue: dict[str, CatalogueEntry], sheets: set[str] | None,
    proposed: Medication | None, result: CheckResult,
) -> tuple[list[_Pair], dict[tuple[str, str], _Search]]:
    """Which pairs to look at and which searches to ask (each search once)."""
    if proposed is None:
        units = _units(medications, catalogue, result)
        for unit in units:
            if len(unit.meds) > 1:
                result.same_ingredient.append(_same_ingredient(unit.meds, unit.ingredients))
        candidates = list(combinations(units, 2))
    else:
        [new] = _units([proposed], catalogue, result) or [None]
        current = _units([m for m in medications if m is not proposed], catalogue, result)
        candidates = [(new, unit) for unit in current] if new else []

    pairs: list[_Pair] = []
    searches: dict[tuple[str, str], _Search] = {}
    missing_notes: dict[str, str] = {}
    for a, b in candidates:
        shared = [i for i in a.ingredients if normalise_text(i) in b.keys]
        if shared:
            result.same_ingredient.append(_same_ingredient(a.meds + b.meds, shared))
            continue
        pair = _Pair(a, b)
        for side, other in ((a, b), (b, a)):
            seen = set()
            for med, entry in zip(side.meds, side.entries):
                if entry.nregistro in seen:
                    continue
                seen.add(entry.nregistro)
                if not _has_sheet(entry, sheets):
                    pair.missing.append(med.nombre)
                    where = "is not in the system" if not entry.ficha else "is not available in this version"
                    missing_notes.setdefault(entry.nregistro, (
                        f"{med.nombre}: its technical sheet {where}, so for its pairs only the other "
                        "medicine's sheet was searched."))
                    continue
                for ingredient in other.ingredients:
                    key = (entry.nregistro, normalise_text(ingredient))
                    searches.setdefault(key, _Search(entry, ingredient))
                    if key not in pair.searches:
                        pair.searches.append(key)
        pairs.append(pair)
    result.could_not_check.extend(missing_notes.values())
    return pairs, searches


def classify_answer(answer: dict) -> tuple[str, str]:
    """Sort one answer from ``review_interaction`` into (outcome, detail).

    outcome is "found", "no_interaction" (found, but the text only says the
    sheet describes no interaction), "not_found" or "failed"."""
    status, reason = answer.get("status"), answer.get("reason")
    response = answer.get("response") or {}
    if status == "found" and not response.get("citations"):  # the pipeline should not allow this
        return "failed", "the answer had no quotation"
    if status == "found" and describes_no_interaction(response.get("description")):
        return "no_interaction", ""
    if status in ("found", "not_found"):
        return status, ""
    return "failed", REASON_TEXT.get(reason, f"the check did not finish ({status}, {reason})")


def _ask(searches: dict[tuple[str, str], _Search], review: Callable[[str, str], dict],
         result: CheckResult, progress: Progress | None, steps: Steps | None = None) -> None:
    """Ask each search once and sort the answer into one of four outcomes."""
    total = len(searches)
    for done, search in enumerate(searches.values()):
        sheet, ingredient = search.sheet, search.ingredient
        if progress:
            progress(done, total, f"Searching the {sheet.nombre} sheet for {ingredient}")
        entry = {"sheet": sheet.nregistro, "ingredient": ingredient}
        try:
            answer = review(sheet.nregistro, ingredient)
        except Exception as exc:  # index or search failure: never "nothing found"
            answer = {"status": "exception", "reason": type(exc).__name__}
            search.outcome, search.detail = "failed", f"the search failed ({type(exc).__name__})"
            result.log.append({**entry, "status": "exception", "reason": type(exc).__name__})
        else:
            status, reason = answer.get("status"), answer.get("reason")
            response = answer.get("response") or {}
            search.outcome, search.detail = classify_answer(answer)
            if search.outcome in ("found", "no_interaction"):
                search.section = response["citations"][0].get("seccion") or ""
            if search.outcome == "found":
                search.answer = response
            if search.outcome == "failed" and status == "found":
                result.log.append({**entry, "status": "rejected", "reason": "no_quotation", "model_status": status})
            elif search.outcome == "no_interaction":
                result.log.append({**entry, "status": "not_found", "reason": "no_interaction_described",
                                   "model_status": status})
            else:
                result.log.append({**entry, "status": status, "reason": reason})
        if steps:
            steps("answered", {"sheet": sheet, "ingredient": ingredient, "answer": answer,
                               "outcome": search.outcome, "detail": search.detail})
    if progress:
        progress(total, total, "Done")


def _interaction_question(pair: _Pair, found: list[_Search], proposed: bool) -> str:
    """Names the sheet(s) and section(s), both medicines and who prescribed them."""
    sources = [f"{s.sheet.nombre} (section {s.section or '4.5'})" for s in found]
    sources = list(dict.fromkeys(sources))
    lead = (f"The technical sheet of {sources[0]} describes" if len(sources) == 1
            else f"The technical sheets of {_join(sources)} describe")
    if proposed:  # pair.a is the proposed medicine; ask about the current prescribers
        who = _join([m.prescriptor for m in pair.b.meds if m.prescriptor != NOT_SPECIFIED])
        ask = (f"Has this combination been reviewed with {who} before prescribing {pair.a.label}?" if who
               else f"Has this combination been reviewed before prescribing {pair.a.label}?")
    else:
        names = list(dict.fromkeys(pair.prescribers))
        ask = (f"{'Has' if len(names) == 1 else 'Have'} {_join(names)} reviewed taking them together?" if names
               else "Have the prescribers involved reviewed taking them together?")
    return f"{lead} a possible interaction between {pair.a.label} and {pair.b.label}. {ask}"


def _sort_pairs(
    pairs: list[_Pair], searches: dict[tuple[str, str], _Search], result: CheckResult, proposed: bool,
) -> None:
    """One result per pair of medicines, whichever direction gave it."""
    questions: dict[tuple[str, str], str] = {}
    found_pairs: list[tuple[_Pair, list[tuple[str, str]], str]] = []
    for pair in pairs:
        outcomes = [searches[k] for k in pair.searches]
        found = [k for k in pair.searches if searches[k].outcome == "found"]
        failed = [s for s in outcomes if s.outcome == "failed"]
        quiet = [s for s in outcomes if s.outcome in ("not_found", "no_interaction")]
        if found:
            question = _interaction_question(pair, [searches[k] for k in found], proposed)
            for k in found:
                questions.setdefault(k, question)
            found_pairs.append((pair, found, question))
        elif failed:
            parts = list(dict.fromkeys(f"{s.sheet.nombre} sheet: {s.detail}" for s in failed))
            searched = list(dict.fromkeys(s.sheet.nombre for s in quiet))
            if searched:
                parts.append(f"nothing found in the {_join(searched)} sheet")
            result.could_not_check.append(f"{pair.label}: {'; '.join(parts)}.")
        elif quiet:
            notes = [f"section {s.section or '4.5'} of the {s.sheet.nombre} sheet mentions this combination "
                     "but describes no relevant interaction" for s in quiet if s.outcome == "no_interaction"]
            if pair.missing:
                searched = list(dict.fromkeys(s.sheet.nombre for s in quiet))
                notes.append(f"only the {_join(searched)} sheet was searched" if len(searched) == 1
                             else f"only the {_join(searched)} sheets were searched")
            notes = list(dict.fromkeys(notes))
            result.checked_without_evidence.append(pair.label + (f" ({'; '.join(notes)})" if notes else ""))
        else:
            result.could_not_check.append(
                f"{pair.label}: neither technical sheet is available, so this pair was not searched.")

    # Findings in the order the searches were asked: the log and the findings
    # then line up one to one (evaluacion/evaluar.py relies on it).
    findings: dict[tuple[str, str], Finding] = {}
    for key, search in searches.items():
        if search.outcome != "found":
            continue
        findings[key] = Finding(
            tipo="interaccion",
            descripcion=search.answer.get("description") or "Information found in the technical sheet.",
            cita=Citation.model_validate(search.answer["citations"][0]),
            pregunta_medico=questions.get(key),
        )
        result.findings.append(findings[key])
    for pair, keys, question in found_pairs:
        result.interaction_groups.append(
            InteractionGroup(title=pair.label, findings=[findings[k] for k in keys], question=question))


# --------------------------------------------------------------------------
# Entry points
# --------------------------------------------------------------------------

def _run(
    medications: list[Medication],
    catalogue: dict[str, CatalogueEntry],
    *,
    proposed: Medication | None,
    rule_data: tuple[dict, dict] | None,
    use_model: bool,
    review: Callable[[str, str], dict] | None,
    sheets: set[str] | None,
    progress: Progress | None,
    steps: Steps | None = None,
) -> CheckResult:
    result = CheckResult()
    proposed_index = len(medications) - 1 if proposed is not None else None
    if rule_data is not None:
        _rule_findings(medications, rule_data, proposed_index, result, catalogue)
    else:
        pairs = ([(proposed, m) for m in medications[:-1]] if proposed is not None
                 else list(combinations(medications, 2)))
        _name_duplicates(pairs, catalogue, proposed, result)
        result.unchecked |= {"advertencia_atc", "cascada"}

    if use_model:
        if review is None:
            review = _import_rag().review_interaction
            sheets = sheets if sheets is not None else index_sheets()
        sheets = sheets if sheets is not None else getattr(review, "sheets", None)
        pairs, searches = _plan(medications, catalogue, sheets, proposed, result)
        _ask(searches, review, result, progress, steps)
        _sort_pairs(pairs, searches, result, proposed is not None)
    else:
        result.unchecked.add("interaccion")
    return result


def check_new_medicine(
    patient: Patient,
    proposed: Medication,
    catalogue: dict[str, CatalogueEntry],
    *,
    rule_data: tuple[dict, dict] | None = None,
    use_model: bool = True,
    review: Callable[[str, str], dict] | None = None,
    sheets: set[str] | None = None,
    progress: Progress | None = None,
    steps: Steps | None = None,
) -> CheckResult:
    """Check ``proposed`` against every medicine in ``patient``.

    ``rule_data`` comes from ``load_rule_data()``; without it the rules part
    falls back to a name comparison. ``review`` defaults to
    ``src.rag.review_interaction``; tests pass a stand-in. ``sheets`` are the
    technical sheets that can be searched (default: the ones in the CIMA file,
    or in the stored answers when ``review`` comes from ``stored_review``).
    """
    if proposed.nregistro not in catalogue:
        raise ValueError(f"{proposed.nombre} is not in the medicine list.")
    medications = list(patient.medicamentos) + [proposed]
    return _run(medications, catalogue, proposed=proposed, rule_data=rule_data,
                use_model=use_model, review=review, sheets=sheets, progress=progress, steps=steps)


def review_patient(
    patient: Patient,
    catalogue: dict[str, CatalogueEntry],
    *,
    rule_data: tuple[dict, dict] | None = None,
    use_model: bool = False,
    review: Callable[[str, str], dict] | None = None,
    sheets: set[str] | None = None,
    progress: Progress | None = None,
    steps: Steps | None = None,
) -> CheckResult:
    """Check every pair of the patient's current medicines."""
    return _run(list(patient.medicamentos), catalogue, proposed=None, rule_data=rule_data,
                use_model=use_model, review=review, sheets=sheets, progress=progress, steps=steps)


def planned_questions(
    patient: Patient, proposed: Medication | None, catalogue: dict[str, CatalogueEntry],
    sheets: set[str] | None = None,
) -> int:
    """How many model questions a check or review will ask (to warn about time)."""
    meds = list(patient.medicamentos) + ([proposed] if proposed is not None else [])
    _, searches = _plan(meds, catalogue, sheets, proposed, CheckResult())
    return len(searches)


# --------------------------------------------------------------------------
# Typed questions: find the medicine, and show the model's steps
# --------------------------------------------------------------------------

# Names a doctor may type in English, mapped to the Spanish names in the list.
INGREDIENT_ALIASES = {
    "metformin": "metformina", "sertraline": "sertralina", "warfarin": "warfarina",
    "levothyroxine": "levotiroxina", "furosemide": "furosemida", "amoxicillin": "amoxicilina",
    "clavulanic acid": "acido clavulanico", "clavulanate": "acido clavulanico",
    "amlodipine": "amlodipino", "simvastatin": "simvastatina", "omeprazole": "omeprazol",
    "acetaminophen": "paracetamol", "atorvastatin": "atorvastatina", "pantoprazole": "pantoprazol",
    "ibuprofen": "ibuprofeno", "sitagliptin": "sitagliptina", "ipratropium": "ipratropio",
    "albuterol": "salbutamol",
}


@dataclass
class Recognised:
    """A medicine from the list that a typed question mentions."""
    entry: CatalogueEntry
    keyword: str          # the words of the question that matched
    already_taken: bool   # the patient already takes this active ingredient


def _words(text: str) -> str:
    return " ".join(re.sub(r"[^\w/]+", " ", normalise_text(text)).split())


def _keywords(catalogue: dict[str, CatalogueEntry]) -> list[tuple[str, str, CatalogueEntry]]:
    """(keyword, kind, entry): the product's name (without the strength) and its
    brand word are "name" keywords; ingredients and their English names are
    "ingredient" keywords."""
    aliases: dict[str, list[str]] = {}
    for english, spanish in INGREDIENT_ALIASES.items():
        aliases.setdefault(spanish, []).append(english)
    table = []
    for entry in catalogue.values():
        ingredients = {_words(i) for i in entry.principios_activos}
        name = _words(entry.nombre).split()
        prefix = []
        for word in name:
            if any(ch.isdigit() for ch in word):
                break
            prefix.append(word)
        if prefix and " ".join(prefix) not in ingredients:
            table.append((" ".join(prefix), "name", entry))
        if prefix and len(prefix[0]) >= 4 and prefix[0] not in ingredients and "/" not in prefix[0]:
            table.append((prefix[0], "name", entry))
        for ingredient in ingredients:
            table.append((ingredient, "ingredient", entry))
            for english in aliases.get(ingredient, []):
                table.append((english, "ingredient", entry))
    return table


def find_medicines(question: str, catalogue: dict[str, CatalogueEntry],
                   patient: Patient | None = None) -> list[Recognised]:
    """The medicines from the list that ``question`` mentions, in the order they
    appear. A product name ("Ibudol", "Atorvastatina Stada") picks that product;
    an active ingredient ("ibuprofeno", "omeprazole") picks every product with
    it, unless the question also names one of them."""
    text = f" {_words(question)} "
    hits: list[tuple[int, str, str, CatalogueEntry]] = []
    for keyword, kind, entry in _keywords(catalogue):
        match = re.search(rf"(?<!\w){re.escape(keyword)}(?!\w)", text)
        if match:
            hits.append((match.start(), keyword, kind, entry))
    named = {h[3].nregistro for h in hits if h[2] == "name"}
    named_ingredients = {_words(i) for h in hits if h[2] == "name" for i in h[3].principios_activos}
    taken = set()
    if patient is not None:
        for med in patient.medicamentos:
            if med.nregistro in catalogue:
                taken |= {_words(i) for i in catalogue[med.nregistro].principios_activos}
    first: dict[str, tuple[int, str]] = {}  # nregistro -> (position, keyword shown)
    for position, keyword, kind, entry in sorted(hits, key=lambda h: (h[2] != "name", h[0], -len(h[1]))):
        ingredients = {_words(i) for i in entry.principios_activos}
        if kind == "ingredient" and entry.nregistro not in named and ingredients & named_ingredients:
            continue  # the question names a specific product with this ingredient
        if entry.nregistro not in first:
            first[entry.nregistro] = (position, keyword)
        else:
            first[entry.nregistro] = (min(position, first[entry.nregistro][0]), first[entry.nregistro][1])
    return [
        Recognised(catalogue[n], keyword,
                   bool({_words(i) for i in catalogue[n].principios_activos} & taken))
        for n, (_, keyword) in sorted(first.items(), key=lambda item: item[1][0])
    ]


_captured_answers: ContextVar[list | None] = ContextVar("captured_model_answers", default=None)

# When Groq does not answer (usually its per-minute limit on the free plan), the
# screen waits this long and asks once more before calling it "could not be checked".
RETRY_PAUSE_SECONDS = 15

# A typed question is answered from the single closest passage of the sheet.
# Three whole sections can be longer than what Groq's free plan accepts in one
# request, and then the question cannot be answered at all.
TYPED_QUESTION_PASSAGES = 1


def _record_model_answers(rag) -> None:
    """Keep a copy of the model's raw answer, so the screen can show what the
    model said even when the checks reject it. Installed once; it only records
    while ``_captured_answers`` is set, and changes nothing else."""
    if getattr(rag.llm_medication_review, "_records_answers", False):
        return
    original = rag.llm_medication_review

    def recording(messages):
        response = original(messages)
        box = _captured_answers.get()
        if box is not None:
            box.append(response)
        return response

    recording._records_answers = True
    rag.llm_medication_review = recording


def _run_with_steps(rag, prepared: dict, retrieved: list[dict], steps: Steps, **about) -> dict:
    kept = {f.get("id") for f in prepared["fragments"]}
    steps("retrieved", {**about, "question": prepared["question"], "retrieved": retrieved, "kept_ids": kept})
    if prepared["fragments"]:
        steps("asking", {**about, "passages": len(prepared["fragments"]), "model": _model_name()})
    box: list = []
    token = _captured_answers.set(box)
    started = time.perf_counter()
    try:
        answer = rag.run_prepared_request(prepared)
        if answer.get("reason") == "generation_failed" and prepared["fragments"]:
            # Usually Groq's per-minute limit on the free plan: wait and try once more.
            steps("retrying", {**about, "seconds": RETRY_PAUSE_SECONDS})
            time.sleep(RETRY_PAUSE_SECONDS)
            started = time.perf_counter()
            answer = rag.run_prepared_request(prepared)
    finally:
        _captured_answers.reset(token)
    answer["model_answer"] = box[-1].model_dump() if box else None
    answer["model_seconds"] = time.perf_counter() - started if box else 0.0
    return answer


def _model_name() -> str:
    try:
        from src.config import GROQ_MODEL
        return GROQ_MODEL
    except ImportError:  # pragma: no cover
        return "the language model"


def live_review_with_steps(steps: Steps) -> Callable[[str, str], dict]:
    """``src.rag.review_interaction``, run step by step so the screen can show
    each step: the passages found in section 4.5, the ones that mention the
    other ingredient, the model's answer and the checks. The answer is the
    same as ``review_interaction``'s (same functions, same order)."""
    rag = _import_rag()
    _record_model_answers(rag)

    def review(nregistro: str, ingredient: str) -> dict:
        prepared = rag.prepare_interaction_search(nregistro, ingredient)
        # The same search prepare_interaction_search ran, before its mention
        # filter, so the screen can show what was left out and why.
        retrieved = rag.search_fragments(prepared["question"], nregistro=nregistro, sections=["4.5"])
        return _run_with_steps(rag, prepared, retrieved, steps, ingredient=ingredient)

    return review


# Words that make a question with no medicine name a question about the
# patient's medicines in general ("¿Hay interacciones?"). Anything else with no
# medicine name ("¿Qué enfermedad tiene?", "¿Cuál es la capital de Francia?")
# is outside what the tool does.
MEDICINE_QUESTION_WORDS = ("interacc", "interact", "combin", "junt", "together", "duplic", "cascad",
                           "medicament", "medicine", "medication", "farmaco", "drug")


def asks_about_medicines(question: str) -> bool:
    text = normalise_text(question)
    return any(word in text for word in MEDICINE_QUESTION_WORDS)


def question_with_context(question: str, patient: Patient, catalogue: dict[str, CatalogueEntry]) -> str:
    """The typed question plus the patient's age and current active ingredients,
    so the search and the model look at what matters for this patient (for
    "¿Puedo añadirle ibuprofeno?", the sheet's text about warfarin or older
    patients) instead of answering in general."""
    ingredients: list[str] = []
    for med in patient.medicamentos:
        entry = catalogue.get(med.nregistro)
        for ingredient in (entry.principios_activos if entry else [med.nombre]):
            if ingredient not in ingredients:
                ingredients.append(ingredient)
    taking = f" que ya toma {_join(ingredients, 'y')}" if ingredients else ""
    return f"{question.strip()} (Contexto: paciente de {patient.edad} años{taking}.)"


def answer_typed_question(question: str, nregistro: str, steps: Steps | None = None) -> dict:
    """Answer a typed question from one medicine's technical sheet with
    ``src.rag`` (all sections), showing the steps when ``steps`` is given."""
    rag = _import_rag()
    _record_model_answers(rag)
    prepared = rag.prepare_general_search(question, nregistro=nregistro, k=TYPED_QUESTION_PASSAGES)
    if steps is None:
        return rag.run_prepared_request(prepared)
    return _run_with_steps(rag, prepared, list(prepared["fragments"]), steps, ingredient=None)
