"""Entry point for a shared link that calls the AI model (Groq) live (Person 5).

Use this file as the "Main file path" of a Streamlit Community Cloud app when
the link must call Groq, not show saved answers. (deploy/streamlit_app.py stays
as the light version that only shows saved answers.)

Community Cloud installs deploy_live/requirements.txt, the packages the RAG
pipeline needs (Groq, ChromaDB, sentence-transformers with a CPU-only PyTorch).

On the first start of the app, this file:
1. Puts the Groq key from the app's Secrets (Settings -> Secrets:
   GROQ_API_KEY = "...") where src/llm.py reads it. The key is never in GitHub.
2. Gets the CIMA technical sheets: from deploy_live/fragmentos_cima.json if
   someone uploaded it, otherwise downloads them from CIMA with Lucía's
   src/parse_cima.py, for every medicine in data/catalogo_medicamentos.json.
3. Builds the search index with src/indice.py (downloads multilingual-e5-small).
Then it runs app.py. Steps 2 and 3 take a few minutes once; later visits reuse
them until the app goes to sleep.

Locally, keep using:  streamlit run app.py
"""
import json
import os
import runpy
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
os.chdir(ROOT)

# ChromaDB needs SQLite 3.35 or newer; some hosting images have an older one.
try:
    __import__("pysqlite3")
    sys.modules["sqlite3"] = sys.modules.pop("pysqlite3")
except ImportError:
    pass

import streamlit as st  # noqa: E402

st.set_page_config(page_title="Medication review", page_icon="💊", layout="wide")

try:
    if not os.getenv("GROQ_API_KEY") and "GROQ_API_KEY" in st.secrets:
        os.environ["GROQ_API_KEY"] = st.secrets["GROQ_API_KEY"]
except Exception:  # no Secrets set: the screen says the key is missing
    pass


def _download_sheets(target: Path) -> str:
    from src import parse_cima
    from src.revision import load_catalogue

    numbers = sorted(n for n, entry in load_catalogue().items() if entry.ficha)
    chunks, errors = [], []
    for nregistro in numbers:
        try:
            chunks.extend(parse_cima.chunks_for_medicine(nregistro, False, errors))
        except Exception as exc:  # one sheet failing must not stop the others
            errors.append({"nregistro": nregistro, "error": f"{type(exc).__name__}: {exc}"})
    if chunks:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(json.dumps(chunks, ensure_ascii=False, indent=2), encoding="utf-8")
    missing = sorted({str(e.get("nregistro")) for e in errors})
    return f"{len(chunks)} passages from CIMA" + (f"; failed: {', '.join(missing)}" if missing else "")


@st.cache_resource(show_spinner="First start: downloading the technical sheets and building the search "
                                "index. This takes a few minutes, once…")
def prepare_search_index() -> str:
    from src.config import DATABASE_DIR, FRAGMENTS_FILE

    note = "search index already there"
    if not FRAGMENTS_FILE.exists():
        shipped = Path(__file__).with_name("fragmentos_cima.json")
        if shipped.exists():
            FRAGMENTS_FILE.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(shipped, FRAGMENTS_FILE)
            note = "technical sheets from deploy_live/fragmentos_cima.json"
        else:
            note = _download_sheets(FRAGMENTS_FILE)
    if FRAGMENTS_FILE.exists() and not DATABASE_DIR.exists():
        from src import indice

        indice.main()
    return note


try:
    prepare_search_index()
except Exception as exc:  # the screen then explains that the model is not available
    st.error(f"The search index could not be prepared ({type(exc).__name__}: {exc}). "
             "Interactions use the saved answers until it is fixed.")

runpy.run_path(str(ROOT / "app.py"), run_name="__main__")
