"""Streamlit interface for the medication review (Person 5).

Run from the project root:

    streamlit run app.py

Two tabs:

* Review current medicines - still uses SAMPLE findings
  (data/demo/hallazgos_ejemplo.json) until the rules (Person 2) are ready.
* Check a new medicine - asks the real model (Person 3's RAG pipeline) about a
  medicine the prescriber is considering, against the patient's current
  medicines. It needs the full requirements, the search index and GROQ_API_KEY.
"""
from __future__ import annotations

import json

import streamlit as st
from pydantic import ValidationError

from src.config import PATIENTS_DIR, PROJECT_ROOT
from src.informe import generate_report, save_report
from src.modelos import Medication, Patient
from src.revision import UNCHECKED_TYPES, check_new_medicine, load_catalogue, model_status

DEMO_DIR = PROJECT_ROOT / "data" / "demo"
DEMO_PATIENTS_FILE = DEMO_DIR / "pacientes_demo.json"
SAMPLE_FINDINGS_FILE = DEMO_DIR / "hallazgos_ejemplo.json"

# Switch to False once run_review() calls the real rules and RAG pipeline.
USE_SAMPLE_FINDINGS = True


def load_patients() -> tuple[list[tuple[Patient, str]], list[str]]:
    """Read Lucía's patient files and the demo patients, validated with Patient."""
    files = [(path, "patients") for path in sorted(PATIENTS_DIR.glob("*.json"))]
    if DEMO_PATIENTS_FILE.exists():
        files.append((DEMO_PATIENTS_FILE, "demo"))

    patients, problems = [], []
    for path, source in files:
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            problems.append(f"{path.name}: could not be read ({exc})")
            continue
        for item in data if isinstance(data, list) else [data]:
            try:
                patients.append((Patient.model_validate(item), source))
            except ValidationError as exc:
                problems.append(f"{path.name}: {exc.error_count()} validation error(s)")
    return patients, problems


def load_sample_findings() -> dict:
    return json.loads(SAMPLE_FINDINGS_FILE.read_text(encoding="utf-8"))


def run_review(patient: Patient) -> tuple[list[dict], list[str]]:
    """Return (findings, pairs checked without information) for one patient.

    TODO (integration), keeping this return shape:
      - Person 2: duplicates, ATC warnings and cascades from src/reglas.py,
        as Finding objects.
      - Person 3: src.rag.review_interaction() for each medicine pair, as in
        src/revision.py.
    """
    if USE_SAMPLE_FINDINGS:
        entry = load_sample_findings().get(patient.id, {})
        return entry.get("hallazgos", []), entry.get("pares_sin_informacion", [])
    raise NotImplementedError("Connect the rules and RAG pipeline here.")


def show_report(report, files: dict, key: str) -> None:
    """Downloads plus the report itself, for either tab."""
    if report.safety_flags:
        st.warning(
            f"{len(report.safety_flags)} generated text(s) were withheld because they "
            "contained treatment-change wording."
        )
    pdf_name, pdf_bytes = files["pdf"]
    html_name, html_bytes = files["html"]
    st.markdown("**Download the report**")
    d1, d2, d3 = st.columns([1, 1, 2])
    d1.download_button("PDF", data=pdf_bytes, file_name=pdf_name,
                       mime="application/pdf", key=f"{key}_pdf")
    d2.download_button("Web page", data=html_bytes, file_name=html_name,
                       mime="text/html", key=f"{key}_html")
    d3.caption(
        "PDF opens in Preview or any PDF reader. The web page opens in your browser "
        "and can be printed. Both are also saved in `output/`."
    )
    st.divider()
    st.markdown(report.markdown)


def saved_files(report) -> dict:
    paths = save_report(report)
    return {kind: (path.name, path.read_bytes()) for kind, path in paths.items()}


st.set_page_config(page_title="Medication review", page_icon="💊", layout="wide")

st.title("Medication review")
st.caption(
    "One view of every medicine a polymedicated patient takes, with each finding traced "
    "to its official source. The system informs; the clinician decides."
)

patients, problems = load_patients()
model_ready, model_message = model_status()

with st.sidebar:
    st.subheader("How it works")
    st.markdown(
        "1. Choose a patient.\n"
        "2. **Review current medicines**, or **check a new medicine** before prescribing it.\n"
        "3. Read the report, or download it as a PDF or a web page.\n\n"
        "Each report is also saved in the `output/` folder."
    )
    show_evaluation = st.checkbox(
        "Show evaluation patients",
        value=False,
        help="Evaluation patients are kept aside for the final evaluation. "
        "Build and test with development patients.",
    )
    if model_ready:
        st.success("Model: connected")
    else:
        st.info(f"Model: not available here. {model_message[:1].upper()}{model_message[1:]}")
    if USE_SAMPLE_FINDINGS:
        st.warning("**Review current medicines** uses sample findings. They are placeholders, "
                   "not clinical information.")
    st.caption("Synthetic patients only.")
    for problem in problems:
        st.error(problem)

visible = [(p, s) for p, s in patients if show_evaluation or p.grupo != "evaluacion"]
visible.sort(key=lambda ps: (ps[0].grupo == "evaluacion", ps[1] == "demo", ps[0].id))
if not visible:
    st.error("No patient files found in data/pacientes.")
    st.stop()

by_id = {p.id: (p, s) for p, s in visible}


def patient_label(pid: str) -> str:
    p, source = by_id[pid]
    tags = (["demo"] if source == "demo" else []) + (["evaluation"] if p.grupo == "evaluacion" else [])
    extra = f"  ({', '.join(tags)})" if tags else ""
    return f"Patient {p.id} · {p.edad} years · {len(p.medicamentos)} medicines{extra}"


patient_id = st.selectbox("Patient", list(by_id), format_func=patient_label)
patient, _ = by_id[patient_id]

prescribers = {m.prescriptor for m in patient.medicamentos}
st.write(f"**{len(patient.medicamentos)} medicines** from **{len(prescribers)} prescribers**")
with st.expander("Medicines on file"):
    st.dataframe(
        [
            {"Medicine": m.nombre, "Dose": m.dosis, "Prescriber": m.prescriptor, "Reg. no.": m.nregistro}
            for m in patient.medicamentos
        ],
        hide_index=True,
    )

tab_review, tab_check = st.tabs(["Review current medicines", "Check a new medicine"])

# --------------------------------------------------------------------------
# Tab 1: review the current medicines (sample findings for now)
# --------------------------------------------------------------------------
with tab_review:
    if USE_SAMPLE_FINDINGS:
        note = load_sample_findings().get(patient.id, {}).get("nota")
        if note:
            st.caption(note)

    if st.button("Review", type="primary", key="review"):
        try:
            with st.spinner("Reviewing medicines…"):
                findings, pairs = run_review(patient)
                report = generate_report(
                    patient, findings, checked_without_evidence=pairs, sample=USE_SAMPLE_FINDINGS
                )
                files = saved_files(report)
            st.session_state["result"] = {"patient_id": patient.id, "report": report, "files": files}
        except Exception as exc:  # show the problem on screen, not a stack trace
            st.session_state.pop("result", None)
            st.error(f"The review could not be completed: {exc}")

    result = st.session_state.get("result")
    if result and result["patient_id"] == patient.id:
        c = result["report"].counts
        cols = st.columns(4)
        cols[0].metric("Duplicates", c["duplicado"])
        cols[1].metric("Same group (ATC)", c["advertencia_atc"])
        cols[2].metric("Interactions", c["interaccion"])
        cols[3].metric("Possible cascades", c["cascada"])
        show_report(result["report"], result["files"], key="review")
    else:
        st.info("Click **Review** to see the report for this patient.")

# --------------------------------------------------------------------------
# Tab 2: check a new medicine with the model
# --------------------------------------------------------------------------
with tab_check:
    st.write(
        "Choose the medicine you're thinking of prescribing. The model searches the official "
        "technical sheets for what they say about it together with this patient's current "
        "medicines, and quotes the text it found."
    )
    catalogue = load_catalogue()
    choices = sorted((e for e in catalogue.values() if e.ficha), key=lambda e: e.nombre.casefold())
    nregistro = st.selectbox(
        "Medicine to prescribe",
        options=[e.nregistro for e in choices],
        format_func=lambda n: f"{catalogue[n].nombre} (reg. {n})",
        index=None,
        placeholder="Choose a medicine",
        help="Only medicines whose technical sheet is in the system can be checked.",
    )
    c1, c2 = st.columns(2)
    dose = c1.text_input("Dose (optional)", placeholder="1 g cada 8 horas")
    prescriber = c2.text_input("Prescriber (optional)", placeholder="Dra. Pérez (Atención Primaria)")

    if not model_ready:
        st.warning(f"The model isn't available here: {model_message}")

    if st.button("Check", type="primary", key="check"):
        if nregistro is None:
            st.error("Choose a medicine first.")
        elif not model_ready:
            st.error(f"The check can't run: {model_message}")
        else:
            proposed = Medication(
                nregistro=nregistro,
                nombre=catalogue[nregistro].nombre,
                dosis=dose.strip() or "Not specified",
                prescriptor=prescriber.strip() or "Not specified",
            )
            bar = st.progress(0.0, text="Asking the model…")
            try:
                checked = check_new_medicine(
                    patient, proposed, catalogue,
                    progress=lambda done, total, label: bar.progress(
                        done / total if total else 1.0, text=label),
                )
                report = generate_report(
                    patient,
                    checked.findings,
                    checked_without_evidence=checked.checked_without_evidence,
                    could_not_check=checked.could_not_check,
                    proposed=proposed,
                    unchecked_types=UNCHECKED_TYPES,
                )
                files = saved_files(report)
                st.session_state["check_result"] = {
                    "patient_id": patient.id, "report": report, "files": files, "log": checked.log,
                }
            except Exception as exc:  # show the problem on screen, not a stack trace
                st.session_state.pop("check_result", None)
                st.error(f"The check could not be completed: {exc}")
            finally:
                bar.empty()

    checked_result = st.session_state.get("check_result")
    if checked_result and checked_result["patient_id"] == patient.id:
        c = checked_result["report"].counts
        cols = st.columns(4)
        cols[0].metric("Same ingredient", c["duplicado"])
        cols[1].metric("Interactions found", c["interaccion"])
        cols[2].metric("Nothing found", c["checked_without_evidence"])
        cols[3].metric("Could not check", c["could_not_check"])
        show_report(checked_result["report"], checked_result["files"], key="check")
