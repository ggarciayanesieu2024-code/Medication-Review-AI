"""Tests for the new-medicine check (src/revision.py) with a stand-in model.

The stand-in replaces src.rag.review_interaction, so these tests need neither the
search index nor a Groq key. Person 3's own tests cover the real pipeline.
"""
import json

import pytest

from src import revision
from src.config import FRAGMENTS_FILE, PATIENTS_DIR, PROJECT_ROOT
from src.informe import FOOTER, generate_report
from src.modelos import Medication, Patient
from src.revision import UNCHECKED_TYPES, check_new_medicine, load_catalogue, model_status

CATALOGUE = load_catalogue()


def _patient(meds, pid="T"):
    return Patient(id=pid, edad=80, grupo="desarrollo", medicamentos=[
        {"nregistro": n, "nombre": CATALOGUE[n].nombre, "dosis": "1 al día", "prescriptor": who}
        for n, who in meds
    ])


def _proposed(nregistro, prescriber="Dra. Pérez (Atención Primaria)"):
    return Medication(nregistro=nregistro, nombre=CATALOGUE[nregistro].nombre,
                      dosis="1 al día", prescriptor=prescriber)


def _found(nregistro):
    return {"status": "found", "reason": None, "response": {
        "status": "found",
        "description": "La ficha describe un posible aumento del riesgo de sangrado.",
        "citations": [{"nregistro": nregistro, "seccion": "4.5",
                       "literal_quote": "puede aumentar el riesgo de hemorragia en pacientes tratados"}],
    }}


class FakeModel:
    """Records every question and answers from a table; default is not_found."""

    def __init__(self, answers=None):
        self.answers = answers or {}
        self.calls = []

    def __call__(self, nregistro, ingredient):
        self.calls.append((nregistro, ingredient))
        answer = self.answers.get((nregistro, ingredient), "not_found")
        if isinstance(answer, Exception):
            raise answer
        if answer == "found":
            return _found(nregistro)
        if answer in ("rejected", "error"):
            reason = "forbidden_phrase" if answer == "rejected" else "generation_failed"
            return {"status": answer, "reason": reason, "response": None}
        return {"status": "not_found", "reason": "no_evidence", "response": None}


# ---------------------------------------------------------------- medicine list

def _all_patient_medicines():
    paths = sorted(PATIENTS_DIR.glob("*.json")) + [PROJECT_ROOT / "data" / "demo" / "pacientes_demo.json"]
    for path in paths:
        data = json.loads(path.read_text(encoding="utf-8"))
        for patient in data if isinstance(data, list) else [data]:
            yield from patient["medicamentos"]


def test_every_patient_medicine_is_in_the_list():
    missing = {m["nregistro"] for m in _all_patient_medicines()} - set(CATALOGUE)
    assert not missing, f"add these registration numbers to data/catalogo_medicamentos.json: {missing}"


def test_every_entry_has_an_ingredient():
    for entry in CATALOGUE.values():
        assert entry.principios_activos and all(i.strip() for i in entry.principios_activos)


def test_list_matches_the_shared_cima_file():
    """Runs only on a computer that has the shared CIMA file."""
    if not FRAGMENTS_FILE.exists():
        pytest.skip("shared CIMA file not in data/processed/")
    fragments = json.loads(FRAGMENTS_FILE.read_text(encoding="utf-8"))
    with_sheet = {f["nregistro"] for f in fragments}
    marked = {n for n, e in CATALOGUE.items() if e.ficha}
    assert marked == with_sheet, (
        f"missing from the list: {with_sheet - marked}; marked but no sheet: {marked - with_sheet}"
    )


# ---------------------------------------------------------------- the check

def test_both_directions_are_asked_and_found_becomes_a_finding():
    patient = _patient([("63064", "Dr. Gómez (Cardiología)")])  # warfarin
    model = FakeModel({("88372", "warfarina"): "found"})          # Ibudol's sheet mentions warfarin
    result = check_new_medicine(patient, _proposed("88372"), CATALOGUE, review=model)

    assert model.calls == [("88372", "warfarina"), ("63064", "ibuprofeno")]
    [finding] = result.findings
    assert finding.tipo == "interaccion" and finding.cita.nregistro == "88372"
    assert "Dr. Gómez (Cardiología)" in finding.pregunta_medico
    assert result.checked_without_evidence == ["Aldocumar 5 mg comprimidos sheet, searched for ibuprofeno"]
    assert result.could_not_check == []


def test_combination_medicine_is_searched_for_each_ingredient():
    patient = _patient([("65222", "Dr. Ibáñez (Urgencias)")])  # amoxicillin + clavulanic acid
    model = FakeModel()
    check_new_medicine(patient, _proposed("63064"), CATALOGUE, review=model)
    assert ("63064", "amoxicilina") in model.calls
    assert ("63064", "ácido clavulánico") in model.calls
    assert ("65222", "warfarina") in model.calls


def test_same_ingredient_is_a_duplicate_and_needs_no_model_question():
    patient = _patient([("68339", "Dra. Martín (Traumatología)")])  # paracetamol
    model = FakeModel()
    result = check_new_medicine(patient, _proposed("85780"), CATALOGUE, review=model)  # Antidol
    assert model.calls == []
    [finding] = result.findings
    assert finding.tipo == "duplicado" and "paracetamol" in finding.descripcion


def test_medicine_without_sheet_is_searched_in_one_direction_only():
    patient = _patient([("07383002", "Dra. Medina (Atención Primaria)")])  # Januvia, no sheet
    model = FakeModel()
    result = check_new_medicine(patient, _proposed("55211"), CATALOGUE, review=model)
    assert model.calls == [("55211", "sitagliptina")]
    assert any("only the Dianben" in item for item in result.could_not_check)


def test_blocked_answers_and_failures_are_never_nothing_found():
    patient = _patient([("63064", "Dr. Gómez (Cardiología)"), ("65461", "Dr. López (Cardiología)")])
    model = FakeModel({
        ("88372", "warfarina"): "rejected",
        ("63064", "ibuprofeno"): "error",
        ("88372", "amlodipino"): RuntimeError("index missing"),
    })
    result = check_new_medicine(patient, _proposed("88372"), CATALOGUE, review=model)
    assert len(result.could_not_check) == 3
    assert not any("warfarina" in item for item in result.checked_without_evidence)
    assert any("safety check" in item for item in result.could_not_check)
    assert any("could not be reached" in item for item in result.could_not_check)
    assert {e["status"] for e in result.log} == {"rejected", "error", "exception", "not_found"}


def test_medicine_without_a_sheet_cannot_be_proposed():
    with pytest.raises(ValueError):
        check_new_medicine(_patient([("63064", "Dr. Gómez")]), _proposed("07383002"),
                           CATALOGUE, review=FakeModel())


def test_progress_reaches_the_end():
    seen = []
    patient = _patient([("63064", "Dr. Gómez"), ("65461", "Dr. López")])
    check_new_medicine(patient, _proposed("88372"), CATALOGUE, review=FakeModel(),
                       progress=lambda done, total, label: seen.append((done, total)))
    assert seen[-1] == (4, 4)


# ---------------------------------------------------------------- report

def test_check_report_lists_the_proposed_medicine_and_unfinished_checks():
    patient = _patient([("63064", "Dr. Gómez (Cardiología)")])
    proposed = _proposed("88372")
    model = FakeModel({("88372", "warfarina"): "found", ("63064", "ibuprofeno"): "rejected"})
    result = check_new_medicine(patient, proposed, CATALOGUE, review=model)
    report = generate_report(
        patient, result.findings, checked_without_evidence=result.checked_without_evidence,
        could_not_check=result.could_not_check, proposed=proposed, unchecked_types=UNCHECKED_TYPES,
    )
    md = report.markdown
    assert "Medicine check before prescribing" in md
    assert "Proposed medicine, not yet prescribed: Dra. Pérez (Atención Primaria)" in md
    assert "Checks that could not be completed" in md
    assert "Not checked: this rule is not connected" in md
    assert "Ibudol 400 mg cápsulas blandas (reg. 88372), section 4.5" in md
    assert report.file_stem.startswith("comprobacion_T_")
    assert report.markdown.rstrip().endswith(f"*{FOOTER}*")


# ---------------------------------------------------------------- model status

def test_model_status_without_libraries(monkeypatch):
    def missing():
        raise ModuleNotFoundError("No module named 'groq'", name="groq")
    monkeypatch.setattr(revision, "_import_rag", missing)
    ready, message = model_status()
    assert not ready and "groq" in message


def test_model_status_without_index(monkeypatch, tmp_path):
    monkeypatch.setattr(revision, "_import_rag", lambda: None)
    ready, message = model_status(tmp_path / "missing")
    assert not ready and "index" in message


def test_model_status_without_key(monkeypatch, tmp_path):
    monkeypatch.setattr(revision, "_import_rag", lambda: None)
    monkeypatch.delenv("GROQ_API_KEY", raising=False)
    ready, message = model_status(tmp_path)
    assert not ready and "GROQ_API_KEY" in message


def test_model_status_ready(monkeypatch, tmp_path):
    monkeypatch.setattr(revision, "_import_rag", lambda: None)
    monkeypatch.setenv("GROQ_API_KEY", "test-key")
    assert model_status(tmp_path) == (True, "connected")
