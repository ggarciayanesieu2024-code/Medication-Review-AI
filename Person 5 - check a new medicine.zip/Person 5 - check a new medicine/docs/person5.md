# Person 5 - Interface, report and evaluation

Last updated: 18 November 2026 (added "Check a new medicine", which asks the real model).

## Status

| Deliverable | Status |
| --- | --- |
| 1. Streamlit screen (`app.py`) | Two tabs. **Check a new medicine** asks the real model (Person 3's RAG). **Review current medicines** still uses sample findings until Person 2's rules are ready. |
| 2. Report (`src/informe.py`, `src/exportar.py`) | Done. Saves PDF and web page to `output/`. |
| 3. Safety cases and report tests | Report tests done (`tests/test_informe.py`). `tests/fixtures/safety_cases.json` pending. |
| 4. 20 evaluation questions (`evaluacion/preguntas.json`) | Pending. Needs the shared CIMA file to check expected answers. |
| 5. Metrics (`evaluacion/`) | Pending. Needs the connected system. |
| 6. Evaluation write-up | Pending. |

## Run the screen

From the project root, with the environment active:

```bash
streamlit run app.py
```

To try only the screen without the full installation, these packages are enough: `streamlit pydantic python-dotenv reportlab`.

Choose a patient, click **Review**, and read the report. **Download the report** offers:

- **PDF**: opens in Preview, Adobe Reader or any browser.
- **Web page**: opens in any browser and has a "Print or save as PDF" button.

Both files are also saved in `output/`, which Git ignores.

Evaluation patients are hidden unless **Show evaluation patients** is ticked in the sidebar.

## Check a new medicine (asks the model)

The prescriber picks a patient, chooses the medicine they are considering, optionally types the dose and their name, and clicks **Check**. The screen never says whether the medicine can or cannot be prescribed. It shows what the official technical sheets say, with the quotation, and the prescriber decides.

What `src/revision.py` does for each medicine the patient already takes:

1. **Same active ingredient:** compares ingredient names from `data/catalogo_medicamentos.json`. If they match, it is a duplicate and no model question is needed. This is a simple stand-in until Person 2's rules are ready.
2. **Interactions:** calls Person 3's `src.rag.review_interaction` in both directions: the new medicine's sheet searched for the current ingredient, and the current medicine's sheet searched for the new ingredient. Combination medicines (for example amoxicillin/clavulanic acid) are searched once per ingredient. A medicine without a sheet in the system is searched in one direction only, and the report says so.
3. **Three kinds of result, kept apart:** `found` becomes a finding with the verified quotation; `not_found` goes to "Pairs checked with no information found" (with the note that this does not mean safe); `rejected`, `error` or a failed search go to "Checks that could not be completed" and are never shown as "nothing found".
4. **Not checked yet:** same therapeutic group (ATC) and cascades are marked "Not checked" in the report, not "None found".

`CheckResult.log` keeps one line per model question (sheet, ingredient, status, reason). The metrics script (deliverable 5) can use it to count found, not found, blocked and failed answers.

### Running it with the real model

This tab only works on a computer that has:

1. the full `requirements.txt` installed,
2. the shared CIMA file from the team Drive saved as `data/processed/fragmentos_cima.json`, and the search index built with `python -m src.indice`,
3. `GROQ_API_KEY` in `.env`.

The sidebar says **Model: connected** when all three are in place, or explains what is missing. Without them the tab still opens but explains why it cannot run.

### The medicine list

`data/catalogo_medicamentos.json` lists every medicine in the patient files, its active ingredients (Spanish names, as the sheets write them) and whether the CIMA file has its sheet (`ficha`). Only medicines with a sheet can be chosen as the new medicine. `tests/test_revision.py` checks that every patient medicine is in the list and, on a computer with the CIMA file, that the `ficha` marks match it. Registration 87970 is in the CIMA file but not in any patient file, so it is not in the list yet.

### Limitations

- The search looks for the ingredient's name. If a sheet only names the group ("AINE", "anticoagulantes orales"), it will not be found from that side. The other direction often still finds it.
- `Finding.cita` holds one citation, so when the model gives several, the report shows the first.
- Every check makes up to two model questions per current medicine (more for combination medicines), so a long medicine list takes a little while. The progress bar shows each search.

### Hosted demo (Streamlit Community Cloud)

The shared link is deployed from Gabi's fork (`ggarciayanesieu2024-code/Medication-Review-AI`, branch `main`) because deploying needs admin rights, which only the repository owner has. Click **Sync fork** on GitHub to bring in new changes. The hosted link has no search index or key, so **Check a new medicine** explains that the model is not available there. Use a laptop with the setup above for the live demo.

The entry point is **Main file path** `deploy/streamlit_app.py`. That entry point runs `app.py` but makes Community Cloud install only `deploy/requirements.txt` (Streamlit, Pydantic, python-dotenv, ReportLab) instead of the full project list with PyTorch. When the app is connected to the real pipeline, add the packages it needs to `deploy/requirements.txt`, and the Groq key under **Advanced settings → Secrets**. Deploying needs admin rights on the GitHub repository. An app deployed from a private repository is private until it is shared.

## Files

| Path | What it is |
| --- | --- |
| `app.py` | Streamlit screen: patient dropdown; tabs **Review current medicines** and **Check a new medicine**; report and downloads |
| `src/informe.py` | Builds the report from `Patient` + `Finding` objects (and a proposed medicine for a check); `FOOTER`; forbidden-phrase check |
| `src/revision.py` | Checks a proposed medicine against the patient's medicines with Person 3's `review_interaction` |
| `data/catalogo_medicamentos.json` | Medicines the screen can use, their active ingredients and whether the system has their sheet |
| `tests/test_revision.py` | The check with a stand-in model: both directions, duplicates, blocked answers, report, model status |
| `src/exportar.py` | Turns the report into a web page (`render_html`) and a PDF (`render_pdf`, ReportLab) |
| `data/demo/pacientes_demo.json` | Four extra development patients for the demo (DEMO_D to DEMO_G) |
| `data/demo/hallazgos_ejemplo.json` | Sample findings per patient (placeholders) and a short note on what each case shows |
| `tests/test_informe.py` | Footer, structure, safety and download tests |

The PDF needs `reportlab`, which is in `deploy/requirements.txt` but still needs adding to the main `requirements.txt` (its owner's file). Until then, run `pip install reportlab` once. Saved reports go to `output/`; adding `output/` to `.gitignore` keeps them out of Git.

## What the report shows

1. Medicines grouped by prescriber, in the order they appear in the patient file
2. Duplicate active ingredients (`tipo: duplicado`)
3. Same therapeutic group (`tipo: advertencia_atc`)
4. Possible interactions (`tipo: interaccion`) with medicine, registration number, section and literal quotation. Pairs checked without information are listed separately, with a note that this does not mean the combination is safe.
5. Possible prescribing cascades (`tipo: cascada`), as hypotheses to review
6. Questions for the next appointment: each finding's `pregunta_medico`, plus a general question about other medicines and supplements
7. The mandatory footer, always last. The PDF also prints it at the bottom of every page.

Descriptions and questions are checked again with the shared `FORBIDDEN_PHRASES` (same normalisation as `src/rag.py`). Text that matches is withheld and counted. Literal quotations are shown unchanged.

## What the screen needs from Persons 2-4

`run_review(patient)` in `app.py` must return:

1. a list of `Finding` objects or dictionaries (`src/modelos.py`), and
2. a list of short texts for pairs checked without information, for example `"Aldocumar 5 mg + Amoxicilina/Ácido clavulánico Tevagen"`.

Suggested mapping from `src.rag.review_interaction()`:

- `found` → `Finding(tipo="interaccion", descripcion=response["description"], cita=<first citation>, pregunta_medico=...)`
- `not_found` → one text for the pair
- `rejected` or `error` → not shown, but counted for the evaluation

To be agreed: who writes the `pregunta_medico` for interactions (rules, RAG, or a fixed template in the report), and whether a finding can carry more than one citation (`Finding.cita` holds one).

## Sample data and demo patients

The sample findings are placeholders for building the screen. They are not expected results, and their quotations are not CIMA text. The report shows a "Sample data" banner while they are in use.

The demo patients use only medicines that appear in the group's patient files, so the real system can analyse them once connected. They are development data, not evaluation data. Lucía should review them; they can move to `data/pacientes/` if the group agrees.

| Patient | What it shows |
| --- | --- |
| A, B, C | Lucía's development patients: duplicate paracetamol; warfarin + antibiotic; nothing to flag |
| DEMO_D | Metformin under two names from two doctors |
| DEMO_E | Warfarin with paracetamol and omeprazole from other doctors |
| DEMO_F | Possible cascade C07: ibuprofen, then amlodipine from another doctor |
| DEMO_G | Five medicines from four doctors, two possible interactions |
| DEMO_H | Carmen's story: ibuprofen, warfarin, paracetamol and pantoprazole from three doctors; three interactions and cascade C14 |

No demo patient shows an ATC warning: the only example available is the statin case, which is evaluation patient E4.

### Development and evaluation patients

Development patients (A, B, C and DEMO_*) are used to build and check the screen, the report and, later, the prompts and rules. Evaluation patients (EVAL_P4 and E1 to E5) are kept aside so the final results measure the system on cases it was not tuned on. They are hidden in the screen unless **Show evaluation patients** is ticked, and the report tests do not use them.

`test_development_patients_do_not_copy_evaluation_cases` checks that no development patient contains an evaluation patient's whole medicine list, or a pair whose result an evaluation patient checks (from `expected_result`). It compares registration numbers, so it does not catch the same scenario with different brands. For that reason, the demo patients were also chosen to avoid the evaluation scenarios: the ibuprofen duplicate (E1), the amlodipine and furosemide cascade (E2), sertraline with warfarin (E3), the two statins (E4) and levothyroxine with a proton pump inhibitor (E5).

## Open points for the group

- ATC/statin case: E4 now says two different statins are not a duplicate. It does not say whether an ATC warning ("same therapeutic group") should appear. Agree this before the evaluation.
- Evaluation patients use two formats: `EVAL_P4` has `resultado_esperado`, and E1 to E5 have `expected_result` and `hypothesis`. The metrics script (deliverable 5) will read both, but one format would be simpler.
- Evaluation patients are not used in Person 5's report tests or sample data.
- `FORBIDDEN_PHRASES` does not catch "ajustar la dosis", which Person 3 observed in a live answer. The safety cases (deliverable 3) will include it.
- Cascade questions in `data/cascadas.json` are in Spanish and the report is in English. Decide one language for the report.
- `data/cascadas.json` changed format (it now has `sources` and `cascades`), but `CascadeCase` in `src/modelos.py` and `tests/test_modelos.py::test_shared_cascade_data` still expect the old list, so that test fails. Whoever changed the file should update the model and the test.
- Interaction checks in **Check a new medicine** use the ingredient's name. Decide whether group names ("AINE", "anticoagulantes") should also be searched; it would find more, but answers would be less specific.
- For the evaluation, do not tune prompts on the medicine pairs that evaluation patients E1 to E5 check (for example sertraline with warfarin).
