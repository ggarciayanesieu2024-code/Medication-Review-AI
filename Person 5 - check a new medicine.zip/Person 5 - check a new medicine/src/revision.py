"""Check a proposed new medicine against a patient's current medicines (Person 5).

For each medicine the patient already takes, the check:

1. Looks for the same active ingredient (a possible duplicate). This is a simple
   name comparison using data/catalogo_medicamentos.json, to be replaced by
   Person 2's rules when src/reglas.py is ready.
2. Asks the model, through Person 3's ``src.rag.review_interaction``, whether
   each technical sheet mentions the other medicine. That function checks one
   direction (sheet X, searched for ingredient Y), so both directions are asked:
   the new medicine's sheet for the current ingredient, and the current
   medicine's sheet for the new ingredient (when the system has that sheet).

Each answer becomes one of three things, which are kept apart on purpose:

* ``found``: a Finding with the verified quotation from the technical sheet.
* ``not_found``: "searched, nothing found", listed separately. This does not
  mean the combination is safe.
* ``rejected`` / ``error`` / an exception: "could not be checked". These are
  never shown as "nothing found"; the pair needs manual review.

The system informs; the prescriber decides. Nothing here says whether the
medicine can or cannot be prescribed.
"""
from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable

from src.config import DATA_DIR, DATABASE_DIR
from src.informe import normalise_text
from src.modelos import Citation, Finding, Medication, Patient

CATALOGUE_FILE = DATA_DIR / "catalogo_medicamentos.json"

# Finding types this check does not cover yet (Person 2's rules are pending).
UNCHECKED_TYPES = ("advertencia_atc", "cascada")

REASON_TEXT = {
    "forbidden_phrase": "the model's answer was blocked by the safety check",
    "invalid_citation": "the model's answer quoted text that could not be verified",
    "invalid_response": "the model's answer was not in the expected format",
    "generation_failed": "the model could not be reached",
}


@dataclass
class CatalogueEntry:
    nregistro: str
    nombre: str
    principios_activos: list[str]
    ficha: bool


@dataclass
class CheckResult:
    findings: list[Finding] = field(default_factory=list)
    checked_without_evidence: list[str] = field(default_factory=list)
    could_not_check: list[str] = field(default_factory=list)
    # One entry per model question, for the evaluation (deliverable 5).
    log: list[dict] = field(default_factory=list)


def load_catalogue(path: str | Path = CATALOGUE_FILE) -> dict[str, CatalogueEntry]:
    """Read the medicine list, keyed by registration number."""
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    return {
        item["nregistro"]: CatalogueEntry(
            nregistro=item["nregistro"],
            nombre=item["nombre"],
            principios_activos=list(item["principios_activos"]),
            ficha=bool(item["ficha"]),
        )
        for item in data["medicamentos"]
    }


def _import_rag():
    from src import rag  # needs groq, chromadb and sentence-transformers

    return rag


def model_status(database_dir: Path = DATABASE_DIR) -> tuple[bool, str]:
    """Return (ready, explanation) for the screen, without calling the model."""
    try:
        _import_rag()
    except ImportError as exc:
        return False, (
            f"the model's libraries are not installed here ({exc.name}). "
            "Install the full requirements.txt."
        )
    if not Path(database_dir).exists():
        return False, (
            "the search index is missing. Put the shared CIMA file in data/processed/ "
            "and run src/indice.py."
        )
    key = os.getenv("GROQ_API_KEY")
    if not key or key == "your_groq_api_key_here":
        return False, "GROQ_API_KEY is missing from the .env file."
    return True, "connected"


def _join(items: list[str]) -> str:
    items = list(dict.fromkeys(i for i in items if i))
    if len(items) <= 1:
        return "".join(items)
    return ", ".join(items[:-1]) + " and " + items[-1]


def planned_questions(patient: Patient, proposed: Medication, catalogue: dict[str, CatalogueEntry]) -> int:
    """How many model questions check_new_medicine will ask (for the progress bar)."""
    new = catalogue[proposed.nregistro]
    new_ings = {normalise_text(i) for i in new.principios_activos}
    total = 0
    for current in patient.medicamentos:
        entry = catalogue.get(current.nregistro)
        if entry is None or new_ings & {normalise_text(i) for i in entry.principios_activos}:
            continue
        total += len(entry.principios_activos)
        if entry.ficha:
            total += len(new.principios_activos)
    return total


def check_new_medicine(
    patient: Patient,
    proposed: Medication,
    catalogue: dict[str, CatalogueEntry],
    *,
    review: Callable[[str, str], dict] | None = None,
    progress: Callable[[int, int, str], None] | None = None,
) -> CheckResult:
    """Check ``proposed`` against every medicine in ``patient``.

    ``review`` defaults to ``src.rag.review_interaction``; tests pass a stand-in.
    ``progress(done, total, label)`` is called before each model question.
    """
    if review is None:
        review = _import_rag().review_interaction
    new = catalogue.get(proposed.nregistro)
    if new is None or not new.ficha:
        raise ValueError(f"{proposed.nombre}: the system has no technical sheet for this medicine.")

    result = CheckResult()
    total = planned_questions(patient, proposed, catalogue)
    done = 0
    new_ings = {normalise_text(i): i for i in new.principios_activos}

    def ask(sheet: CatalogueEntry, ingredient: str, current: Medication) -> None:
        nonlocal done
        label = f"{sheet.nombre} sheet, searched for {ingredient}"
        if progress:
            progress(done, total, f"Searching the {sheet.nombre} sheet for {ingredient}")
        done += 1
        try:
            answer = review(sheet.nregistro, ingredient)
        except Exception as exc:  # index or search failure: never "nothing found"
            result.log.append({"sheet": sheet.nregistro, "ingredient": ingredient,
                               "status": "exception", "reason": type(exc).__name__})
            result.could_not_check.append(f"{label}: the search failed ({type(exc).__name__}).")
            return

        status, reason = answer.get("status"), answer.get("reason")
        result.log.append({"sheet": sheet.nregistro, "ingredient": ingredient,
                           "status": status, "reason": reason})
        if status == "found":
            response = answer.get("response") or {}
            citations = response.get("citations") or []
            if not citations:  # the pipeline should not allow this; be safe anyway
                result.could_not_check.append(f"{label}: the answer had no quotation.")
                return
            who = _join([current.prescriptor, proposed.prescriptor if proposed.prescriptor != "Not specified" else ""])
            result.findings.append(Finding(
                tipo="interaccion",
                descripcion=response.get("description") or "Information found in the technical sheet.",
                cita=Citation.model_validate(citations[0]),
                pregunta_medico=(
                    f"Have the prescribers involved ({who}) reviewed the combined use of "
                    f"{proposed.nombre} and {current.nombre}?"
                ),
            ))
        elif status == "not_found":
            result.checked_without_evidence.append(label)
        else:
            why = REASON_TEXT.get(reason, f"the check did not finish ({status}, {reason})")
            result.could_not_check.append(f"{label}: {why}.")

    for current in patient.medicamentos:
        entry = catalogue.get(current.nregistro)
        if entry is None:
            result.could_not_check.append(
                f"{current.nombre}: not in the medicine list, so its active ingredient is unknown."
            )
            continue

        shared = [new_ings[n] for n in (normalise_text(i) for i in entry.principios_activos) if n in new_ings]
        if shared:
            ingredient = _join(shared)
            result.findings.append(Finding(
                tipo="duplicado",
                descripcion=(
                    f"The proposed medicine ({proposed.nombre}) and {current.nombre}, prescribed by "
                    f"{current.prescriptor}, contain the same active ingredient: {ingredient}."
                ),
                pregunta_medico=(
                    f"The patient already takes {current.nombre}. What total daily amount of "
                    f"{ingredient} would the patient take with both?"
                ),
            ))
            continue

        # Direction 1: the new medicine's sheet, searched for each current ingredient.
        for ingredient in entry.principios_activos:
            ask(new, ingredient, current)
        # Direction 2: the current medicine's sheet, searched for each new ingredient.
        if entry.ficha:
            for ingredient in new.principios_activos:
                ask(entry, ingredient, current)
        else:
            result.could_not_check.append(
                f"{current.nombre} sheet: not in the system, so only the {new.nombre} sheet was searched."
            )

    if progress:
        progress(total, total, "Done")
    return result
